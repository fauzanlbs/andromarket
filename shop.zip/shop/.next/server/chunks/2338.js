"use strict";
exports.id = 2338;
exports.ids = [2338];
exports.modules = {

/***/ 2338:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_mailchimp_subscribe__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(182);
/* harmony import */ var react_mailchimp_subscribe__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_mailchimp_subscribe__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9297);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _components_ui_input__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(4271);
/* harmony import */ var _components_ui_button__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7993);
/* harmony import */ var react_hook_form__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(2662);
/* harmony import */ var react_hook_form__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_hook_form__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _hookform_resolvers_yup__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(2166);
/* harmony import */ var _hookform_resolvers_yup__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_hookform_resolvers_yup__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var next_i18next__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(8475);
/* harmony import */ var next_i18next__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(next_i18next__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var yup__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(9440);
/* harmony import */ var yup__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(yup__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _contexts_ui_context__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(4580);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(5282);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__);
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }












const defaultValues = {
  subscribe_email: ""
}; // Yup validation

const subscriptionFormSchema = yup__WEBPACK_IMPORTED_MODULE_7__.object().shape({
  subscribe_email: yup__WEBPACK_IMPORTED_MODULE_7__.string().email("forms:email-error").required("forms:email-required")
});

const CustomForm = ({
  status,
  message,
  onValidated,
  layout
}) => {
  var _errors$subscribe_ema;

  const {
    register,
    handleSubmit,
    reset,
    formState: {
      errors
    }
  } = (0,react_hook_form__WEBPACK_IMPORTED_MODULE_4__.useForm)({
    defaultValues,
    resolver: (0,_hookform_resolvers_yup__WEBPACK_IMPORTED_MODULE_5__.yupResolver)(subscriptionFormSchema)
  });
  const {
    t
  } = (0,next_i18next__WEBPACK_IMPORTED_MODULE_6__.useTranslation)();
  const {
    closeModal
  } = (0,_contexts_ui_context__WEBPACK_IMPORTED_MODULE_8__/* .useUI */ .l8)();
  const {
    0: responseMessage,
    1: setResponseMessage
  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
  (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(() => {
    setResponseMessage(message); // Disappear message after 2 second

    const interval = setInterval(() => {
      setResponseMessage("");
    }, 3000);
    return () => {
      clearInterval(interval);
    };
  }, [message]);

  async function onSubmit(input) {
    await onValidated({
      EMAIL: input.subscribe_email
    }); // Reset the form

    reset({
      subscribe_email: ""
    }); // If layout newsletter then close the model

    if (layout === "newsletter") {
      closeModal();
    }
  } // Generate layout className


  const layoutClassName = _objectSpread({}, layout === "newsletter" ? {
    formClassName: "pt-8 sm:pt-10 md:pt-14 mb-1 sm:mb-0",
    divClassName: "",
    inputClassName: "px-4 lg:px-7 h-12 lg:h-14 text-center bg-gray-50",
    buttonClassName: "w-full h-12 lg:h-14 mt-3 sm:mt-4",
    buttonTextClassName: "lg:py-0.5"
  } : {
    formClassName: "flex-shrink-0 w-full sm:w-96 md:w-[545px]",
    divClassName: "flex flex-col sm:flex-row items-start justify-end",
    inputClassName: "px-4 lg:px-7 h-12 lg:h-14 text-center sm:text-start bg-white",
    buttonClassName: "mt-3 sm:mt-0 w-full sm:w-auto sm:ms-2 md:h-full flex-shrink-0",
    buttonTextClassName: "lg:py-0.5"
  });

  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxs)("form", {
    onSubmit: handleSubmit(onSubmit),
    className: layoutClassName.formClassName,
    children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxs)("div", {
      className: layoutClassName.divClassName,
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx(_components_ui_input__WEBPACK_IMPORTED_MODULE_2__/* .default */ .Z, _objectSpread(_objectSpread({
        placeholderKey: "forms:placeholder-email-subscribe",
        type: "email",
        variant: "solid",
        className: "w-full",
        inputClassName: layoutClassName.inputClassName
      }, register("subscribe_email")), {}, {
        errorKey: (_errors$subscribe_ema = errors.subscribe_email) === null || _errors$subscribe_ema === void 0 ? void 0 : _errors$subscribe_ema.message
      })), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx(_components_ui_button__WEBPACK_IMPORTED_MODULE_3__/* .default */ .Z, {
        className: layoutClassName.buttonClassName,
        loading: status === "sending",
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx("span", {
          className: layoutClassName.buttonTextClassName,
          children: t(`common:button-subscribe`)
        })
      })]
    }), status === "success" && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx("div", {
      className: "my-2 text-xs text-green-600" // @ts-ignore
      ,
      dangerouslySetInnerHTML: {
        __html: responseMessage
      }
    }), status === "error" && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx("div", {
      className: "my-2 text-xs text-red-500" // @ts-ignore
      ,
      dangerouslySetInnerHTML: {
        __html: responseMessage
      }
    })]
  });
};

const MailchimpForm = ({
  layout = "newsletter"
}) => {
  const url = "";
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx((react_mailchimp_subscribe__WEBPACK_IMPORTED_MODULE_0___default()), {
    url: url,
    render: ({
      subscribe,
      status,
      message
    }) => /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx(CustomForm, {
      status: status,
      message: message,
      layout: layout,
      onValidated: formData => subscribe(formData)
    })
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (MailchimpForm);

/***/ }),

/***/ 4271:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(4058);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9297);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_i18next__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8475);
/* harmony import */ var next_i18next__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_i18next__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5282);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__);
const _excluded = ["className", "labelKey", "name", "errorKey", "placeholderKey", "variant", "shadow", "type", "inputClassName"];

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }






const classes = {
  root: "py-2 px-4 md:px-5 w-full appearance-none transition duration-150 ease-in-out border text-input text-xs md:text-[13px] lg:text-sm font-body rounded-md placeholder-body min-h-12 transition duration-200 ease-in-out",
  normal: "bg-gray-100 border-gray-300 focus:shadow focus:bg-white focus:border-primary",
  solid: "bg-white border-gray-300 focus:outline-none focus:border-heading h-11 md:h-12",
  outline: "border-gray-300 focus:border-heading focus-visible:outline-none",
  shadow: "focus:shadow"
};
const Input = /*#__PURE__*/react__WEBPACK_IMPORTED_MODULE_1___default().forwardRef((_ref, ref) => {
  let {
    className = "block",
    labelKey,
    name,
    errorKey,
    placeholderKey,
    variant = "normal",
    shadow = false,
    type = "text",
    inputClassName
  } = _ref,
      rest = _objectWithoutProperties(_ref, _excluded);

  const rootClassName = classnames__WEBPACK_IMPORTED_MODULE_0___default()(classes.root, {
    [classes.normal]: variant === "normal",
    [classes.solid]: variant === "solid",
    [classes.outline]: variant === "outline"
  }, {
    [classes.shadow]: shadow
  }, inputClassName);
  const {
    t
  } = (0,next_i18next__WEBPACK_IMPORTED_MODULE_2__.useTranslation)();
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxs)("div", {
    className: className,
    children: [labelKey && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("label", {
      htmlFor: name,
      className: "block text-gray-600 font-semibold text-sm leading-none mb-3 cursor-pointer",
      children: t(labelKey)
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("input", _objectSpread({
      id: name,
      name: name,
      type: type,
      ref: ref // @ts-ignore
      ,
      placeholder: t(placeholderKey),
      className: rootClassName,
      autoComplete: "off",
      spellCheck: "false",
      "aria-invalid": errorKey ? "true" : "false"
    }, rest)), errorKey && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx("p", {
      className: "my-2 text-xs text-red-500",
      children: t(errorKey)
    })]
  });
});
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Input);

/***/ })

};
;