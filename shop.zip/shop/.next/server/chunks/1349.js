"use strict";
exports.id = 1349;
exports.ids = [1349];
exports.modules = {

/***/ 2577:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ sale_with_progress)
});

// EXTERNAL MODULE: ./src/components/product/product-card.tsx
var product_card = __webpack_require__(135);
// EXTERNAL MODULE: ./src/components/ui/carousel/carousel.tsx
var carousel = __webpack_require__(4365);
// EXTERNAL MODULE: external "swiper/react"
var react_ = __webpack_require__(2156);
// EXTERNAL MODULE: external "react-content-loader"
var external_react_content_loader_ = __webpack_require__(9081);
var external_react_content_loader_default = /*#__PURE__*/__webpack_require__.n(external_react_content_loader_);
// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(5282);
;// CONCATENATED MODULE: ./src/components/ui/loaders/product-flash-sale-grid-loader.tsx
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }





const ProductFlashSaleGridLoader = props => /*#__PURE__*/(0,jsx_runtime_.jsxs)((external_react_content_loader_default()), _objectSpread(_objectSpread({
  speed: 2,
  width: 315,
  height: 542,
  viewBox: "0 0 315 542",
  backgroundColor: "#f9f9f9",
  foregroundColor: "#ecebeb",
  className: "w-full h-auto"
}, props), {}, {
  children: [/*#__PURE__*/jsx_runtime_.jsx("rect", {
    x: "0",
    y: "0",
    rx: "6",
    ry: "6",
    width: "315",
    height: "315"
  }), /*#__PURE__*/jsx_runtime_.jsx("rect", {
    x: "0",
    y: "372",
    rx: "4",
    ry: "4",
    width: "260",
    height: "6"
  }), /*#__PURE__*/jsx_runtime_.jsx("rect", {
    x: "0",
    y: "408",
    rx: "4",
    ry: "4",
    width: "90",
    height: "10"
  }), /*#__PURE__*/jsx_runtime_.jsx("rect", {
    x: "0",
    y: "526",
    rx: "13",
    ry: "13",
    width: "315",
    height: "16"
  }), /*#__PURE__*/jsx_runtime_.jsx("rect", {
    x: "0",
    y: "340",
    rx: "4",
    ry: "4",
    width: "170",
    height: "8"
  }), /*#__PURE__*/jsx_runtime_.jsx("rect", {
    x: "0",
    y: "492",
    rx: "4",
    ry: "4",
    width: "35",
    height: "8"
  }), /*#__PURE__*/jsx_runtime_.jsx("rect", {
    x: "42",
    y: "492",
    rx: "4",
    ry: "4",
    width: "80",
    height: "8"
  }), /*#__PURE__*/jsx_runtime_.jsx("rect", {
    x: "193",
    y: "492",
    rx: "4",
    ry: "4",
    width: "35",
    height: "8"
  }), /*#__PURE__*/jsx_runtime_.jsx("rect", {
    x: "235",
    y: "492",
    rx: "4",
    ry: "4",
    width: "80",
    height: "8"
  })]
}));

/* harmony default export */ const product_flash_sale_grid_loader = (ProductFlashSaleGridLoader);
;// CONCATENATED MODULE: ./src/components/ui/loaders/product-flash-sale-loader.tsx
function product_flash_sale_loader_ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function product_flash_sale_loader_objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { product_flash_sale_loader_ownKeys(Object(source), true).forEach(function (key) { product_flash_sale_loader_defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { product_flash_sale_loader_ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function product_flash_sale_loader_defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }





const ProductFlashSaleLoader = props => /*#__PURE__*/(0,jsx_runtime_.jsxs)((external_react_content_loader_default()), product_flash_sale_loader_objectSpread(product_flash_sale_loader_objectSpread({
  speed: 2,
  width: 515,
  height: 318,
  viewBox: "0 0 515 318",
  backgroundColor: "#f9f9f9",
  foregroundColor: "#ecebeb",
  className: "w-full h-auto"
}, props), {}, {
  children: [/*#__PURE__*/jsx_runtime_.jsx("rect", {
    x: "0",
    y: "0",
    rx: "6",
    ry: "6",
    width: "208",
    height: "208"
  }), /*#__PURE__*/jsx_runtime_.jsx("rect", {
    x: "236",
    y: "98",
    rx: "4",
    ry: "4",
    width: "260",
    height: "6"
  }), /*#__PURE__*/jsx_runtime_.jsx("rect", {
    x: "236",
    y: "135",
    rx: "4",
    ry: "4",
    width: "90",
    height: "10"
  }), /*#__PURE__*/jsx_runtime_.jsx("rect", {
    x: "0",
    y: "302",
    rx: "13",
    ry: "13",
    width: "515",
    height: "16"
  }), /*#__PURE__*/jsx_runtime_.jsx("rect", {
    x: "236",
    y: "66",
    rx: "4",
    ry: "4",
    width: "170",
    height: "8"
  }), /*#__PURE__*/jsx_runtime_.jsx("rect", {
    x: "0",
    y: "267",
    rx: "4",
    ry: "4",
    width: "35",
    height: "8"
  }), /*#__PURE__*/jsx_runtime_.jsx("rect", {
    x: "45",
    y: "267",
    rx: "4",
    ry: "4",
    width: "80",
    height: "8"
  }), /*#__PURE__*/jsx_runtime_.jsx("rect", {
    x: "388",
    y: "267",
    rx: "4",
    ry: "4",
    width: "35",
    height: "8"
  }), /*#__PURE__*/jsx_runtime_.jsx("rect", {
    x: "433",
    y: "267",
    rx: "4",
    ry: "4",
    width: "80",
    height: "8"
  })]
}));

/* harmony default export */ const product_flash_sale_loader = (ProductFlashSaleLoader);
// EXTERNAL MODULE: external "next-i18next"
var external_next_i18next_ = __webpack_require__(8475);
;// CONCATENATED MODULE: ./src/components/common/progress-card.tsx




const ProgressCard = ({
  soldProduct = 0,
  totalProduct = 0
}) => {
  const progressBar = 100 / totalProduct * soldProduct;
  const {
    t
  } = (0,external_next_i18next_.useTranslation)("common");
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
    children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      className: "flex justify-between items-center mb-2.5 md:mb-3 xl:mb-2.5 2xl:mb-4",
      children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: "text-body text-xs md:text-sm leading-6 md:leading-7",
        children: [t("text-sold"), " :\xA0", /*#__PURE__*/jsx_runtime_.jsx("span", {
          className: "text-heading",
          children: soldProduct
        })]
      }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: "text-body text-xs md:text-sm leading-6 md:leading-7",
        children: [t("text-available"), " :\xA0", /*#__PURE__*/jsx_runtime_.jsx("span", {
          className: "text-heading",
          children: totalProduct - soldProduct
        })]
      })]
    }), /*#__PURE__*/jsx_runtime_.jsx("div", {
      className: "relative w-full h-2.5 lg:h-3 2xl:h-4 bg-gray-100 rounded-full overflow-hidden",
      children: /*#__PURE__*/jsx_runtime_.jsx("div", {
        className: "absolute h-full bg-heading",
        style: {
          width: `${Math.round(progressBar)}%`
        }
      })
    })]
  });
};

/* harmony default export */ const progress_card = (ProgressCard);
// EXTERNAL MODULE: ./src/components/common/section-header.tsx
var section_header = __webpack_require__(7125);
// EXTERNAL MODULE: ./src/components/ui/alert.tsx
var ui_alert = __webpack_require__(5013);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(9297);
;// CONCATENATED MODULE: ./src/components/common/sale-with-progress.tsx












const breakpoints = {
  "1441": {
    slidesPerView: 1
  },
  "768": {
    slidesPerView: 2,
    spaceBetween: 20
  },
  "0": {
    slidesPerView: 1,
    spaceBetween: 12
  }
};

const SellWithProgress = ({
  products,
  loading,
  error,
  className = "",
  productVariant = "list",
  imgWidth = 210,
  imgHeight = 210,
  carouselBreakpoint
}) => {
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
    className: `flex flex-col border border-gray-300 rounded-lg pt-6 sm:pt-7 lg:pt-8 xl:pt-7 2xl:pt-9 px-4 md:px-5 lg:px-7 pb-6 lg:pb-7 ${productVariant !== "gridSlim" && "xl:px-5 2xl:px-7"} ${className}`,
    children: [/*#__PURE__*/jsx_runtime_.jsx(section_header/* default */.Z, {
      sectionHeading: "text-flash-sale",
      className: "mb-4 md:mb-5 lg:mb-6 xl:mb-5 2xl:mb-6 3xl:mb-8"
    }), error ? /*#__PURE__*/jsx_runtime_.jsx(ui_alert/* default */.Z, {
      message: error
    }) : /*#__PURE__*/jsx_runtime_.jsx(jsx_runtime_.Fragment, {
      children: loading ? /*#__PURE__*/jsx_runtime_.jsx("div", {
        className: `heightFull ${productVariant === "gridSlim" && "2xl:pt-1.5 3xl:pt-0"}`,
        children: /*#__PURE__*/jsx_runtime_.jsx(carousel/* default */.Z, {
          breakpoints: carouselBreakpoint ? carouselBreakpoint : breakpoints,
          buttonSize: "small",
          buttonClassName: productVariant === "gridSlim" ? "-top-12 md:-top-14 lg:-top-28 2xl:-top-32" : "-top-12 md:-top-14",
          className: "-mx-0 md:-mx-2.5 xl:-mx-0",
          children: productVariant === "gridSlim" ? Array.from({
            length: 3
          }).map((_, idx) => /*#__PURE__*/jsx_runtime_.jsx(react_.SwiperSlide, {
            children: /*#__PURE__*/jsx_runtime_.jsx(product_flash_sale_grid_loader, {
              uniqueKey: `product-grid-${idx}`
            })
          }, `product-grid-${idx}`)) : Array.from({
            length: 10
          }).map((_, idx) => /*#__PURE__*/jsx_runtime_.jsx(react_.SwiperSlide, {
            children: /*#__PURE__*/jsx_runtime_.jsx(product_flash_sale_loader, {
              uniqueKey: `product-${idx}`
            })
          }, `product-${idx}`))
        })
      }) : (products === null || products === void 0 ? void 0 : products.length) && /*#__PURE__*/jsx_runtime_.jsx("div", {
        className: `heightFull ${productVariant === "gridSlim" ? "2xl:pt-1.5 3xl:pt-0" : ""}`,
        children: /*#__PURE__*/jsx_runtime_.jsx(carousel/* default */.Z, {
          breakpoints: carouselBreakpoint ? carouselBreakpoint : breakpoints,
          buttonSize: "small",
          buttonClassName: productVariant === "gridSlim" ? "-top-12 md:-top-14 lg:-top-28 2xl:-top-32" : "-top-12 md:-top-14",
          children: products.map(product => {
            var _product$orders_count;

            return /*#__PURE__*/jsx_runtime_.jsx(react_.SwiperSlide, {
              children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
                className: "h-full flex flex-col justify-between",
                children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
                  className: "mb-5 sm:mb-7 lg:mb-8 2xl:mb-10 3xl:mb-12",
                  children: /*#__PURE__*/jsx_runtime_.jsx(product_card/* default */.Z, {
                    product: product,
                    imgWidth: imgWidth,
                    imgHeight: imgHeight,
                    variant: productVariant,
                    contactClassName: `${productVariant === "list" && "ps-4 lg:ps-6 3xl:ps-7"}`,
                    imageContentClassName: `${productVariant === "list" && "flex-shrink-0 w-32 sm:w-44 md:w-36 lg:w-48 xl:w-40 2xl:w-44 3xl:w-52"}`
                  })
                }), /*#__PURE__*/jsx_runtime_.jsx(progress_card, {
                  soldProduct: (_product$orders_count = product === null || product === void 0 ? void 0 : product.orders_count) !== null && _product$orders_count !== void 0 ? _product$orders_count : 0,
                  totalProduct: product === null || product === void 0 ? void 0 : product.quantity
                })]
              })
            }, `product--key${product.id}`);
          })
        })
      })
    })]
  });
};

/* harmony default export */ const sale_with_progress = (SellWithProgress);

/***/ }),

/***/ 5748:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _components_common_card__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(3765);
/* harmony import */ var _components_common_section_header__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7125);
/* harmony import */ var _components_ui_carousel_carousel__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(4365);
/* harmony import */ var swiper_react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2156);
/* harmony import */ var swiper_react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(swiper_react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _components_ui_loaders_card_rounded_loader__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1802);
/* harmony import */ var _framework_brand_brands_query__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(4412);
/* harmony import */ var _lib_routes__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1103);
/* harmony import */ var _components_ui_alert__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(5013);
/* harmony import */ var lodash_isEmpty__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(8718);
/* harmony import */ var lodash_isEmpty__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(lodash_isEmpty__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _components_404_not_found_item__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(6857);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(9297);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var next_i18next__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(8475);
/* harmony import */ var next_i18next__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(next_i18next__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var _lib_filter_brands__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(7640);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(5282);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__);















const breakpoints = {
  "1720": {
    slidesPerView: 8,
    spaceBetween: 28
  },
  "1400": {
    slidesPerView: 7,
    spaceBetween: 28
  },
  "1025": {
    slidesPerView: 6,
    spaceBetween: 28
  },
  "768": {
    slidesPerView: 5,
    spaceBetween: 20
  },
  "500 ": {
    slidesPerView: 4,
    spaceBetween: 20
  },
  "0": {
    slidesPerView: 3,
    spaceBetween: 12
  }
};

const BrandBlock = ({
  className = "mb-11 md:mb-11 lg:mb-12 xl:mb-14 lg:pb-1 xl:pb-0",
  sectionHeading
}) => {
  var _data$pages, _data$pages$, _data$pages2, _data$pages2$;

  const {
    t
  } = (0,next_i18next__WEBPACK_IMPORTED_MODULE_11__.useTranslation)();
  const {
    data,
    isLoading: loading,
    error
  } = (0,_framework_brand_brands_query__WEBPACK_IMPORTED_MODULE_5__/* .useBrandsQuery */ .ac)({});

  if (!loading && lodash_isEmpty__WEBPACK_IMPORTED_MODULE_8___default()(data === null || data === void 0 ? void 0 : (_data$pages = data.pages) === null || _data$pages === void 0 ? void 0 : (_data$pages$ = _data$pages[0]) === null || _data$pages$ === void 0 ? void 0 : _data$pages$.data)) {
    return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_components_404_not_found_item__WEBPACK_IMPORTED_MODULE_9__/* .default */ .Z, {
      text: t("text-no-brands-found")
    });
  } // Filter brands for grid layout


  const sliderBrand = (0,_lib_filter_brands__WEBPACK_IMPORTED_MODULE_13__/* .filterBrands */ .b)(data === null || data === void 0 ? void 0 : (_data$pages2 = data.pages) === null || _data$pages2 === void 0 ? void 0 : (_data$pages2$ = _data$pages2[0]) === null || _data$pages2$ === void 0 ? void 0 : _data$pages2$.data, "slider-layout");
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsxs)("div", {
    className: className,
    children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_components_common_section_header__WEBPACK_IMPORTED_MODULE_1__/* .default */ .Z, {
      sectionHeading: sectionHeading
    }), error ? /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_components_ui_alert__WEBPACK_IMPORTED_MODULE_7__/* .default */ .Z, {
      message: error === null || error === void 0 ? void 0 : error.message
    }) : /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_components_ui_carousel_carousel__WEBPACK_IMPORTED_MODULE_2__/* .default */ .Z, {
      breakpoints: breakpoints,
      loop: false,
      buttonClassName: "-mt-8 md:-mt-12",
      children: loading && !data ? Array.from({
        length: 7
      }).map((_, idx) => /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(swiper_react__WEBPACK_IMPORTED_MODULE_3__.SwiperSlide, {
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_components_ui_loaders_card_rounded_loader__WEBPACK_IMPORTED_MODULE_4__/* .default */ .Z, {
          uniqueKey: `category-${idx}`
        })
      }, idx)) : sliderBrand === null || sliderBrand === void 0 ? void 0 : sliderBrand.map(brand => /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(swiper_react__WEBPACK_IMPORTED_MODULE_3__.SwiperSlide, {
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_12__.jsx(_components_common_card__WEBPACK_IMPORTED_MODULE_0__/* .default */ .Z, {
          item: brand,
          variant: "rounded",
          size: "medium",
          href: {
            pathname: _lib_routes__WEBPACK_IMPORTED_MODULE_6__/* .ROUTES.SEARCH */ .Z.SEARCH,
            query: {
              brand: brand.slug
            }
          }
        })
      }, `brand--key${brand.id}`))
    })]
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (BrandBlock);

/***/ })

};
;