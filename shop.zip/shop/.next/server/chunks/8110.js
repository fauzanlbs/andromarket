"use strict";
exports.id = 8110;
exports.ids = [8110];
exports.modules = {

/***/ 8110:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ ProductPopup)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9297);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6731);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var lodash_isEmpty__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8718);
/* harmony import */ var lodash_isEmpty__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(lodash_isEmpty__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _lib_routes__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1103);
/* harmony import */ var _contexts_ui_context__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(4580);
/* harmony import */ var _components_ui_button__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(7993);
/* harmony import */ var _components_common_counter__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(1654);
/* harmony import */ var _components_product_product_attributes__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(9582);
/* harmony import */ var _utils_generate_cart_item__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(4064);
/* harmony import */ var _lib_use_price__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(7259);
/* harmony import */ var _framework_utils_get_variations__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(2347);
/* harmony import */ var next_i18next__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(8475);
/* harmony import */ var next_i18next__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(next_i18next__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var _framework_products_products_query__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(2317);
/* harmony import */ var lodash_isEqual__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(6414);
/* harmony import */ var lodash_isEqual__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(lodash_isEqual__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var _components_ui_loaders_spinner_spinner__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(9204);
/* harmony import */ var _components_product_product_variant_price__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(7615);
/* harmony import */ var _store_quick_cart_cart_context__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(4436);
/* harmony import */ var react_toastify__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(2034);
/* harmony import */ var react_toastify__WEBPACK_IMPORTED_MODULE_17___default = /*#__PURE__*/__webpack_require__.n(react_toastify__WEBPACK_IMPORTED_MODULE_17__);
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(3804);
/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_18___default = /*#__PURE__*/__webpack_require__.n(lodash__WEBPACK_IMPORTED_MODULE_18__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(5282);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_19___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_19__);
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }























function ProductPopup({
  productSlug
}) {
  var _product$image$origin, _product$image, _selectedVariation, _selectedVariation2, _selectedVariation3;

  const {
    t
  } = (0,next_i18next__WEBPACK_IMPORTED_MODULE_11__.useTranslation)("common");
  const {
    closeModal,
    openCart
  } = (0,_contexts_ui_context__WEBPACK_IMPORTED_MODULE_4__/* .useUI */ .l8)();
  const {
    data: product,
    isLoading: loading
  } = (0,_framework_products_products_query__WEBPACK_IMPORTED_MODULE_12__/* .useProductQuery */ .FA)(productSlug);
  const router = (0,next_router__WEBPACK_IMPORTED_MODULE_1__.useRouter)();
  const {
    addItemToCart
  } = (0,_store_quick_cart_cart_context__WEBPACK_IMPORTED_MODULE_16__/* .useCart */ .jD)();
  const {
    0: quantity,
    1: setQuantity
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(1);
  const {
    0: attributes,
    1: setAttributes
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)({});
  const {
    0: viewCartBtn,
    1: setViewCartBtn
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
  const {
    0: addToCartLoader,
    1: setAddToCartLoader
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
  const {
    price,
    basePrice
  } = (0,_lib_use_price__WEBPACK_IMPORTED_MODULE_9__/* .default */ .ZP)({
    amount: product !== null && product !== void 0 && product.sale_price ? product === null || product === void 0 ? void 0 : product.sale_price : product === null || product === void 0 ? void 0 : product.price,
    baseAmount: product === null || product === void 0 ? void 0 : product.price
  });
  const variations = (0,_framework_utils_get_variations__WEBPACK_IMPORTED_MODULE_10__/* .getVariations */ .y)(product === null || product === void 0 ? void 0 : product.variations);
  const isSelected = !lodash_isEmpty__WEBPACK_IMPORTED_MODULE_2___default()(variations) ? !lodash_isEmpty__WEBPACK_IMPORTED_MODULE_2___default()(attributes) && Object.keys(variations).every(variation => attributes.hasOwnProperty(variation)) : true;
  let selectedVariation = {};

  if (isSelected) {
    var _product$variation_op;

    selectedVariation = product === null || product === void 0 ? void 0 : (_product$variation_op = product.variation_options) === null || _product$variation_op === void 0 ? void 0 : _product$variation_op.find(o => lodash_isEqual__WEBPACK_IMPORTED_MODULE_13___default()(o.options.map(v => v.value).sort(), Object.values(attributes).sort()));
  }

  function addToCart() {
    if (!isSelected) return; // to show btn feedback while product carting

    setAddToCartLoader(true);
    setTimeout(() => {
      setAddToCartLoader(false);
      setViewCartBtn(true);
    }, 600);
    const item = (0,_utils_generate_cart_item__WEBPACK_IMPORTED_MODULE_8__/* .generateCartItem */ .z)(product, selectedVariation);
    addItemToCart(item, quantity);
    (0,react_toastify__WEBPACK_IMPORTED_MODULE_17__.toast)("Added to the bag", {
      type: "dark",
      progressClassName: "fancy-progress-bar",
      position: "top-right",
      autoClose: 2000,
      hideProgressBar: false,
      closeOnClick: true,
      pauseOnHover: true,
      draggable: true
    });
  }

  function navigateToProductPage() {
    closeModal();
    router.push(`${_lib_routes__WEBPACK_IMPORTED_MODULE_3__/* .ROUTES.PRODUCT */ .Z.PRODUCT}/${productSlug}`, undefined, {
      locale: router.locale
    });
  }

  function handleAttribute(attribute) {
    // Reset Quantity
    if (!(0,lodash__WEBPACK_IMPORTED_MODULE_18__.isMatch)(attributes, attribute)) {
      setQuantity(1);
    }

    setAttributes(prev => _objectSpread(_objectSpread({}, prev), attribute));
  }

  function navigateToCartPage() {
    closeModal();
    setTimeout(() => {
      openCart();
    }, 300);
  }

  if (loading) {
    return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_19__.jsx("div", {
      className: "w-96 flex justify-center items-center h-96 bg-white relative overflow-hidden",
      children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_19__.jsx(_components_ui_loaders_spinner_spinner__WEBPACK_IMPORTED_MODULE_14__/* .default */ .Z, {})
    });
  }

  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_19__.jsx("div", {
    className: "rounded-lg bg-white",
    children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_19__.jsxs)("div", {
      className: "flex flex-col lg:flex-row w-full md:w-[650px] lg:w-[960px] mx-auto overflow-hidden",
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_19__.jsx("div", {
        className: "flex-shrink-0 flex items-center justify-center w-full lg:w-430px max-h-430px lg:max-h-full overflow-hidden bg-gray-300",
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_19__.jsx("img", {
          src: (_product$image$origin = product === null || product === void 0 ? void 0 : (_product$image = product.image) === null || _product$image === void 0 ? void 0 : _product$image.original) !== null && _product$image$origin !== void 0 ? _product$image$origin : "/assets/placeholder/products/product-thumbnail.svg",
          alt: product.name,
          className: "lg:object-cover lg:w-full lg:h-full"
        })
      }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_19__.jsxs)("div", {
        className: "flex flex-col p-5 md:p-8 w-full",
        children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_19__.jsxs)("div", {
          className: "pb-5",
          children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_19__.jsx("div", {
            className: "mb-2 md:mb-2.5 block -mt-1.5",
            onClick: navigateToProductPage,
            role: "button",
            children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_19__.jsx("h2", {
              className: "text-heading text-lg md:text-xl lg:text-2xl font-semibold hover:text-black",
              children: product.name
            })
          }), product.unit && lodash_isEmpty__WEBPACK_IMPORTED_MODULE_2___default()(variations) && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_19__.jsx("span", {
            className: "text-sm font-normal text-body mt-2 md:mt-3 block",
            children: product.unit
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_19__.jsx("p", {
            className: "text-sm leading-6 md:text-body md:leading-7",
            children: product.description
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_19__.jsx("div", {
            className: "flex items-center mt-3",
            children: !lodash_isEmpty__WEBPACK_IMPORTED_MODULE_2___default()(variations) ? /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_19__.jsx(_components_product_product_variant_price__WEBPACK_IMPORTED_MODULE_15__/* .default */ .Z, {
              selectedVariation: selectedVariation,
              minPrice: product.min_price,
              maxPrice: product.max_price
            }) : /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_19__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_19__.Fragment, {
              children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_19__.jsx("div", {
                className: "text-heading font-semibold text-base md:text-xl lg:text-2xl",
                children: price
              }), basePrice && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_19__.jsx("del", {
                className: "font-segoe text-gray-400 text-base lg:text-xl ps-2.5 -mt-0.5 md:mt-0",
                children: basePrice
              })]
            })
          })]
        }), Object.keys(variations).map(variation => {
          return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_19__.jsx(_components_product_product_attributes__WEBPACK_IMPORTED_MODULE_7__/* .ProductAttributes */ .P, {
            title: variation,
            attributes: variations[variation],
            active: attributes[variation],
            onClick: handleAttribute
          }, `popup-attribute-key${variation}`);
        }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_19__.jsxs)("div", {
          className: "pt-2 md:pt-4",
          children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_19__.jsxs)("div", {
            className: "flex items-center justify-between mb-4 space-s-3 sm:space-s-4",
            children: [lodash_isEmpty__WEBPACK_IMPORTED_MODULE_2___default()(variations) && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_19__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_19__.Fragment, {
              children: Number(product.quantity) > 0 ? /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_19__.jsx(_components_common_counter__WEBPACK_IMPORTED_MODULE_6__/* .default */ .Z, {
                quantity: quantity,
                onIncrement: () => setQuantity(prev => prev + 1),
                onDecrement: () => setQuantity(prev => prev !== 1 ? prev - 1 : 1),
                disableDecrement: quantity === 1,
                disableIncrement: Number(product.quantity) === quantity
              }) : /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_19__.jsx("div", {
                className: "text-base text-red-500 whitespace-nowrap lg:ms-7",
                children: t("text-out-stock")
              })
            }), !lodash_isEmpty__WEBPACK_IMPORTED_MODULE_2___default()(selectedVariation) && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_19__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_19__.Fragment, {
              children: (_selectedVariation = selectedVariation) !== null && _selectedVariation !== void 0 && _selectedVariation.is_disable || selectedVariation.quantity === 0 ? /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_19__.jsx("div", {
                className: "text-base text-red-500 whitespace-nowrap lg:ms-7",
                children: t("text-out-stock")
              }) : /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_19__.jsx(_components_common_counter__WEBPACK_IMPORTED_MODULE_6__/* .default */ .Z, {
                quantity: quantity,
                onIncrement: () => setQuantity(prev => prev + 1),
                onDecrement: () => setQuantity(prev => prev !== 1 ? prev - 1 : 1),
                disableDecrement: quantity === 1,
                disableIncrement: Number(selectedVariation.quantity) === quantity
              })
            }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_19__.jsx(_components_ui_button__WEBPACK_IMPORTED_MODULE_5__/* .default */ .Z, {
              onClick: addToCart,
              variant: "slim",
              className: `w-full md:w-6/12 xl:w-full ${!isSelected && "bg-gray-400 hover:bg-gray-400"}`,
              disabled: !isSelected || !(product !== null && product !== void 0 && product.quantity) || !lodash_isEmpty__WEBPACK_IMPORTED_MODULE_2___default()(selectedVariation) && !((_selectedVariation2 = selectedVariation) !== null && _selectedVariation2 !== void 0 && _selectedVariation2.quantity),
              loading: addToCartLoader,
              children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_19__.jsx("span", {
                className: "py-2 3xl:px-8",
                children: product !== null && product !== void 0 && product.quantity || !lodash_isEmpty__WEBPACK_IMPORTED_MODULE_2___default()(selectedVariation) && (_selectedVariation3 = selectedVariation) !== null && _selectedVariation3 !== void 0 && _selectedVariation3.quantity ? t("text-add-to-cart") : t("text-out-stock")
              })
            })]
          }), viewCartBtn && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_19__.jsx("button", {
            onClick: navigateToCartPage,
            className: "w-full mb-4 h-11 md:h-12 rounded bg-gray-100 text-heading focus:outline-none border border-gray-300 transition-colors hover:bg-gray-50 focus:bg-gray-50",
            children: t("text-view-cart")
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_19__.jsx(_components_ui_button__WEBPACK_IMPORTED_MODULE_5__/* .default */ .Z, {
            onClick: navigateToProductPage,
            variant: "flat",
            className: "w-full h-11 md:h-12",
            children: t("text-view-details")
          })]
        })]
      })]
    })
  });
}

/***/ })

};
;