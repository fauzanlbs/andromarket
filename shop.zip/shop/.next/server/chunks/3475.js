"use strict";
exports.id = 3475;
exports.ids = [3475];
exports.modules = {

/***/ 5313:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5282);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);


const Divider = ({
  className = "mb-12 lg:mb-14 xl:mb-16 pb-0.5 lg:pb-1 xl:pb-0"
}) => {
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
    className: `border-t border-gray-300 ${className}`
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Divider);

/***/ }),

/***/ 4533:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "A": () => (/* binding */ fetchAttributes),
/* harmony export */   "O": () => (/* binding */ useAttributesQuery)
/* harmony export */ });
/* harmony import */ var _framework_utils_core_api__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(3036);
/* harmony import */ var _framework_utils_endpoints__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(874);
/* harmony import */ var react_query__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2585);
/* harmony import */ var react_query__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_query__WEBPACK_IMPORTED_MODULE_2__);



const AttributesService = new _framework_utils_core_api__WEBPACK_IMPORTED_MODULE_0__/* .CoreApi */ .z(_framework_utils_endpoints__WEBPACK_IMPORTED_MODULE_1__/* .API_ENDPOINTS.ATTRIBUTES */ .P.ATTRIBUTES);
const fetchAttributes = async () => {
  const {
    data
  } = await AttributesService.findAll();
  return {
    attributes: data
  };
};
const useAttributesQuery = () => {
  return (0,react_query__WEBPACK_IMPORTED_MODULE_2__.useQuery)(_framework_utils_endpoints__WEBPACK_IMPORTED_MODULE_1__/* .API_ENDPOINTS.ATTRIBUTES */ .P.ATTRIBUTES, fetchAttributes);
};

/***/ }),

/***/ 9658:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "f": () => (/* binding */ fetchBanners),
/* harmony export */   "E": () => (/* binding */ useBannerQuery)
/* harmony export */ });
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2376);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_query__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2585);
/* harmony import */ var react_query__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_query__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _framework_utils_endpoints__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(874);



const fetchBanners = () => {
  return axios__WEBPACK_IMPORTED_MODULE_0___default().get(`${"https://andromarket.id"}/${_framework_utils_endpoints__WEBPACK_IMPORTED_MODULE_2__/* .API_ENDPOINTS.BANNERS */ .P.BANNERS}`).then(res => res === null || res === void 0 ? void 0 : res.data);
};
function useBannerQuery() {
  return (0,react_query__WEBPACK_IMPORTED_MODULE_1__.useQuery)(_framework_utils_endpoints__WEBPACK_IMPORTED_MODULE_2__/* .API_ENDPOINTS.BANNERS */ .P.BANNERS, fetchBanners);
}

/***/ }),

/***/ 4362:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "p": () => (/* binding */ fetchCategories),
/* harmony export */   "E": () => (/* binding */ useCategoriesQuery)
/* harmony export */ });
/* harmony import */ var _framework_utils_core_api__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(3036);
/* harmony import */ var _framework_utils_endpoints__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(874);
/* harmony import */ var react_query__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2585);
/* harmony import */ var react_query__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_query__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _framework_utils_data_mappers__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(9517);
const _excluded = ["data"];

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }





const CategoryService = new _framework_utils_core_api__WEBPACK_IMPORTED_MODULE_0__/* .CoreApi */ .z(_framework_utils_endpoints__WEBPACK_IMPORTED_MODULE_1__/* .API_ENDPOINTS.CATEGORIES */ .P.CATEGORIES);
const fetchCategories = async ({
  queryKey,
  pageParam
}) => {
  const params = queryKey[1];
  let fetchedData = {};

  if (pageParam) {
    const response = await CategoryService.fetchUrl(pageParam);
    fetchedData = response.data;
  } else {
    const response = await CategoryService.find(params);
    fetchedData = response.data;
  }

  const {
    data
  } = fetchedData,
        rest = _objectWithoutProperties(fetchedData, _excluded);

  return {
    data,
    paginatorInfo: (0,_framework_utils_data_mappers__WEBPACK_IMPORTED_MODULE_3__/* .mapPaginatorData */ .Q)(_objectSpread({}, rest))
  };
};
const useCategoriesQuery = (params, options) => {
  return (0,react_query__WEBPACK_IMPORTED_MODULE_2__.useInfiniteQuery)([_framework_utils_endpoints__WEBPACK_IMPORTED_MODULE_1__/* .API_ENDPOINTS.PRODUCTS */ .P.PRODUCTS, params], fetchCategories, _objectSpread(_objectSpread({}, options), {}, {
    getNextPageParam: ({
      paginatorInfo
    }) => paginatorInfo.nextPageUrl
  }));
};

/***/ }),

/***/ 9218:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "b": () => (/* binding */ getStaticProps)
/* harmony export */ });
/* harmony import */ var _framework_settings_settings_query__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(659);
/* harmony import */ var _framework_category_categories_query__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(4362);
/* harmony import */ var _framework_brand_brands_query__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(4412);
/* harmony import */ var _framework_products_products_query__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2317);
/* harmony import */ var _framework_utils_endpoints__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(874);
/* harmony import */ var next_i18next_serverSideTranslations__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(3295);
/* harmony import */ var next_i18next_serverSideTranslations__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_i18next_serverSideTranslations__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var react_query__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(2585);
/* harmony import */ var react_query__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react_query__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var react_query_hydration__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(9475);
/* harmony import */ var react_query_hydration__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react_query_hydration__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _framework_menu_menu_query__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(5210);
/* harmony import */ var _framework_banner_banner_query__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(9658);
/* harmony import */ var _framework_attributes_attributes_query__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(4533);
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }












const getStaticProps = async ({
  locale
}) => {
  const queryClient = new react_query__WEBPACK_IMPORTED_MODULE_6__.QueryClient();
  await queryClient.prefetchQuery(_framework_utils_endpoints__WEBPACK_IMPORTED_MODULE_4__/* .API_ENDPOINTS.SETTINGS */ .P.SETTINGS, _framework_settings_settings_query__WEBPACK_IMPORTED_MODULE_0__/* .fetchSettings */ .w);
  await queryClient.prefetchInfiniteQuery([_framework_utils_endpoints__WEBPACK_IMPORTED_MODULE_4__/* .API_ENDPOINTS.PRODUCTS */ .P.PRODUCTS, {}], _framework_products_products_query__WEBPACK_IMPORTED_MODULE_3__/* .fetchProducts */ .t2, {
    staleTime: 60 * 1000
  });
  await queryClient.prefetchQuery([_framework_utils_endpoints__WEBPACK_IMPORTED_MODULE_4__/* .API_ENDPOINTS.PARENT_CATEGORIES */ .P.PARENT_CATEGORIES, {}], _framework_category_categories_query__WEBPACK_IMPORTED_MODULE_1__/* .fetchCategories */ .p, {
    staleTime: 60 * 1000
  });
  await queryClient.prefetchQuery(_framework_utils_endpoints__WEBPACK_IMPORTED_MODULE_4__/* .API_ENDPOINTS.TYPE */ .P.TYPE, _framework_brand_brands_query__WEBPACK_IMPORTED_MODULE_2__/* .fetchBrands */ .S0, {
    staleTime: 60 * 1000
  });
  await queryClient.prefetchQuery(_framework_utils_endpoints__WEBPACK_IMPORTED_MODULE_4__/* .API_ENDPOINTS.MENU */ .P.MENU, _framework_menu_menu_query__WEBPACK_IMPORTED_MODULE_8__/* .fetchMenus */ .P, {
    staleTime: 60 * 1000
  });
  await queryClient.prefetchQuery(_framework_utils_endpoints__WEBPACK_IMPORTED_MODULE_4__/* .API_ENDPOINTS.BANNERS */ .P.BANNERS, _framework_banner_banner_query__WEBPACK_IMPORTED_MODULE_9__/* .fetchBanners */ .f, {
    staleTime: 60 * 1000
  });
  await queryClient.prefetchQuery(_framework_utils_endpoints__WEBPACK_IMPORTED_MODULE_4__/* .API_ENDPOINTS.ATTRIBUTES */ .P.ATTRIBUTES, _framework_attributes_attributes_query__WEBPACK_IMPORTED_MODULE_10__/* .fetchAttributes */ .A, {
    staleTime: 60 * 1000
  });
  return {
    props: _objectSpread(_objectSpread({}, await (0,next_i18next_serverSideTranslations__WEBPACK_IMPORTED_MODULE_5__.serverSideTranslations)(locale, ["common", "menu", "forms", "footer"])), {}, {
      dehydratedState: JSON.parse(JSON.stringify((0,react_query_hydration__WEBPACK_IMPORTED_MODULE_7__.dehydrate)(queryClient)))
    }),
    revalidate: 120
  };
};

/***/ })

};
;