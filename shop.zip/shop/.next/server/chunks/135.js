"use strict";
exports.id = 135;
exports.ids = [135];
exports.modules = {

/***/ 135:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(4058);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8579);
/* harmony import */ var _contexts_ui_context__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(4580);
/* harmony import */ var _lib_use_price__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7259);
/* harmony import */ var _settings_site_settings__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5278);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(5282);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__);









const ProductCard = ({
  product,
  className = "",
  contactClassName = "",
  imageContentClassName = "",
  variant = "list",
  imgWidth = 340,
  imgHeight = 440,
  imgLoading
}) => {
  var _image$original, _siteSettings$product;

  const {
    openModal,
    setModalView,
    setModalData
  } = (0,_contexts_ui_context__WEBPACK_IMPORTED_MODULE_2__/* .useUI */ .l8)();
  const {
    name,
    image,
    min_price,
    max_price,
    product_type,
    description
  } = product !== null && product !== void 0 ? product : {};
  const {
    price,
    basePrice
  } = (0,_lib_use_price__WEBPACK_IMPORTED_MODULE_3__/* .default */ .ZP)({
    amount: product !== null && product !== void 0 && product.sale_price ? product === null || product === void 0 ? void 0 : product.sale_price : product === null || product === void 0 ? void 0 : product.price,
    baseAmount: product === null || product === void 0 ? void 0 : product.price
  });
  const {
    price: minPrice
  } = (0,_lib_use_price__WEBPACK_IMPORTED_MODULE_3__/* .default */ .ZP)({
    amount: min_price
  });
  const {
    price: maxPrice
  } = (0,_lib_use_price__WEBPACK_IMPORTED_MODULE_3__/* .default */ .ZP)({
    amount: max_price
  });

  function handlePopupView() {
    setModalData(product.slug);
    setModalView("PRODUCT_VIEW");
    return openModal();
  }

  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxs)("div", {
    className: classnames__WEBPACK_IMPORTED_MODULE_0___default()("group box-border overflow-hidden flex rounded-md cursor-pointer", {
      "pe-0 pb-2 lg:pb-3 flex-col items-start bg-white transition duration-200 ease-in-out transform hover:-translate-y-1 hover:md:-translate-y-1.5 hover:shadow-product": variant === "grid",
      "pe-0 md:pb-1 flex-col items-start bg-white": variant === "gridSlim",
      "items-center bg-transparent border border-gray-100 transition duration-200 ease-in-out transform hover:-translate-y-1 hover:shadow-listProduct": variant === "listSmall",
      "flex-row items-center transition-transform ease-linear bg-gray-200 pe-2 lg:pe-3 2xl:pe-4": variant === "list"
    }, className),
    onClick: handlePopupView,
    role: "button",
    title: name,
    children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx("div", {
      className: classnames__WEBPACK_IMPORTED_MODULE_0___default()("flex", {
        "mb-3 md:mb-3.5": variant === "grid",
        "mb-3 md:mb-3.5 pb-0": variant === "gridSlim",
        "flex-shrink-0 w-32 sm:w-44 md:w-36 lg:w-44": variant === "listSmall"
      }, imageContentClassName),
      children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx(next_image__WEBPACK_IMPORTED_MODULE_1__.default, {
        src: (_image$original = image === null || image === void 0 ? void 0 : image.original) !== null && _image$original !== void 0 ? _image$original : _settings_site_settings__WEBPACK_IMPORTED_MODULE_4__/* .siteSettings */ .U === null || _settings_site_settings__WEBPACK_IMPORTED_MODULE_4__/* .siteSettings */ .U === void 0 ? void 0 : (_siteSettings$product = _settings_site_settings__WEBPACK_IMPORTED_MODULE_4__/* .siteSettings.product */ .U.product) === null || _siteSettings$product === void 0 ? void 0 : _siteSettings$product.placeholderImage(),
        width: imgWidth,
        height: imgHeight,
        loading: imgLoading,
        quality: 100,
        alt: name || "Product Image",
        className: classnames__WEBPACK_IMPORTED_MODULE_0___default()("bg-gray-300 object-cover rounded-s-md", {
          "w-full rounded-md transition duration-200 ease-in group-hover:rounded-b-none": variant === "grid",
          "rounded-md transition duration-150 ease-linear transform group-hover:scale-105": variant === "gridSlim",
          "rounded-s-md transition duration-200 ease-linear transform group-hover:scale-105": variant === "list"
        })
      })
    }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxs)("div", {
      className: classnames__WEBPACK_IMPORTED_MODULE_0___default()("w-full overflow-hidden", {
        "ps-0 lg:ps-2.5 xl:ps-4 pe-2.5 xl:pe-4": variant === "grid",
        "ps-0": variant === "gridSlim",
        "px-4 lg:px-5 2xl:px-4": variant === "listSmall"
      }, contactClassName),
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx("h2", {
        className: classnames__WEBPACK_IMPORTED_MODULE_0___default()("text-heading font-semibold truncate mb-1", {
          "text-sm md:text-base": variant === "grid",
          "md:mb-1.5 text-sm sm:text-base md:text-sm lg:text-base xl:text-lg": variant === "gridSlim",
          "text-sm sm:text-base md:mb-1.5 pb-0": variant === "listSmall",
          "text-sm sm:text-base md:text-sm lg:text-base xl:text-lg md:mb-1.5": variant === "list"
        }),
        children: name
      }), description && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx("p", {
        className: "text-body text-xs md:text-[13px] lg:text-sm leading-normal xl:leading-relaxed max-w-[250px] truncate",
        children: description
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx("div", {
        className: `text-heading font-semibold text-sm sm:text-base mt-1.5 space-s-1 ${variant === "grid" ? "3xl:text-lg lg:mt-2.5" : "sm:text-lg md:text-base 3xl:text-xl md:mt-2.5 2xl:mt-3"}`,
        children: product_type.toLocaleLowerCase() === "variable" ? /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.Fragment, {
          children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx("span", {
            className: "inline-block",
            children: minPrice
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx("span", {
            children: " - "
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx("span", {
            className: "inline-block",
            children: maxPrice
          })]
        }) : /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.Fragment, {
          children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx("span", {
            className: "inline-block",
            children: price
          }), basePrice && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx("del", {
            className: "sm:text-base font-normal text-gray-800 ps-1",
            children: basePrice
          })]
        })
      })]
    })]
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ProductCard);

/***/ })

};
;