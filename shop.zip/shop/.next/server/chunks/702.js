"use strict";
exports.id = 702;
exports.ids = [702];
exports.modules = {

/***/ 702:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_hook_form__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2662);
/* harmony import */ var react_hook_form__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_hook_form__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_icons_im__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(688);
/* harmony import */ var next_i18next__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8475);
/* harmony import */ var next_i18next__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_i18next__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var yup__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(9440);
/* harmony import */ var yup__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(yup__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _components_ui_input__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(4271);
/* harmony import */ var _components_ui_password_input__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5090);
/* harmony import */ var _components_ui_button__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(7993);
/* harmony import */ var _framework_auth_auth_query__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(6838);
/* harmony import */ var _contexts_ui_context__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(4580);
/* harmony import */ var _components_ui_logo__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(4386);
/* harmony import */ var _hookform_resolvers_yup__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(2166);
/* harmony import */ var _hookform_resolvers_yup__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(_hookform_resolvers_yup__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _components_ui_alert__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(5013);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(9297);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var js_cookie__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(6155);
/* harmony import */ var js_cookie__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(js_cookie__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var next_auth_client__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(8104);
/* harmony import */ var next_auth_client__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(next_auth_client__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var jotai__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(8250);
/* harmony import */ var jotai__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(jotai__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var _store_authorization_atom__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(8879);
/* harmony import */ var _lib_constants__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(509);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(5282);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_16___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_16__);
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

 // @ts-ignore




















const loginFormSchema = yup__WEBPACK_IMPORTED_MODULE_2__.object().shape({
  email: yup__WEBPACK_IMPORTED_MODULE_2__.string().email("forms:email-error").required("forms:email-required"),
  password: yup__WEBPACK_IMPORTED_MODULE_2__.string().required("forms:password-required")
});
const defaultValues = {
  email: "",
  password: ""
};

const LoginForm = () => {
  var _errors$email, _errors$password;

  const {
    setModalView,
    openModal,
    closeModal
  } = (0,_contexts_ui_context__WEBPACK_IMPORTED_MODULE_7__/* .useUI */ .l8)();
  const {
    t
  } = (0,next_i18next__WEBPACK_IMPORTED_MODULE_1__.useTranslation)();
  const {
    0: errorMessage,
    1: setErrorMessage
  } = (0,react__WEBPACK_IMPORTED_MODULE_11__.useState)("");
  const [_, authorize] = (0,jotai__WEBPACK_IMPORTED_MODULE_14__.useAtom)(_store_authorization_atom__WEBPACK_IMPORTED_MODULE_15__/* .authorizationAtom */ .O);
  const {
    mutate: login,
    isLoading: loading
  } = (0,_framework_auth_auth_query__WEBPACK_IMPORTED_MODULE_6__/* .useLoginMutation */ .YA)();
  const {
    register,
    handleSubmit,
    formState: {
      errors
    }
  } = (0,react_hook_form__WEBPACK_IMPORTED_MODULE_0__.useForm)({
    resolver: (0,_hookform_resolvers_yup__WEBPACK_IMPORTED_MODULE_9__.yupResolver)(loginFormSchema),
    defaultValues
  });

  function onSubmit({
    email,
    password,
    remember_me
  }) {
    login({
      email,
      password
    }, {
      onSuccess: data => {
        var _data$permissions;

        if (data !== null && data !== void 0 && data.token && data !== null && data !== void 0 && (_data$permissions = data.permissions) !== null && _data$permissions !== void 0 && _data$permissions.length) {
          js_cookie__WEBPACK_IMPORTED_MODULE_12___default().set(_lib_constants__WEBPACK_IMPORTED_MODULE_17__/* .AUTH_TOKEN */ .UA, data.token, {
            expires: remember_me ? 365 : undefined
          });
          authorize(true);
          closeModal();
          return;
        }

        if (!data.token) {
          setErrorMessage(t("forms:error-credential-wrong"));
        }
      },
      onError: error => {
        console.log(error.message);
      }
    });
  }

  function handleSignUp() {
    setModalView("SIGN_UP_VIEW");
    return openModal();
  }

  function handleForgetPassword() {
    setModalView("FORGET_PASSWORD");
    return openModal();
  }

  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_16__.jsxs)("div", {
    className: "overflow-hidden bg-white mx-auto rounded-lg w-full sm:w-96 md:w-450px border border-gray-300 py-5 px-5 sm:px-8",
    children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_16__.jsxs)("div", {
      className: "text-center mb-6 pt-2.5",
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_16__.jsx("div", {
        onClick: closeModal,
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_16__.jsx(_components_ui_logo__WEBPACK_IMPORTED_MODULE_8__/* .default */ .Z, {})
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_16__.jsx("p", {
        className: "text-sm md:text-base text-body mt-2 mb-8 sm:mb-10",
        children: t("common:login-helper")
      })]
    }), errorMessage && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_16__.jsx(_components_ui_alert__WEBPACK_IMPORTED_MODULE_10__/* .default */ .Z, {
      message: errorMessage,
      variant: "error",
      className: "my-3"
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_16__.jsx("form", {
      onSubmit: handleSubmit(onSubmit),
      className: "flex flex-col justify-center",
      noValidate: true,
      children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_16__.jsxs)("div", {
        className: "flex flex-col space-y-3.5",
        children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_16__.jsx(_components_ui_input__WEBPACK_IMPORTED_MODULE_3__/* .default */ .Z, _objectSpread(_objectSpread({
          labelKey: "forms:label-email-star",
          type: "email",
          variant: "solid"
        }, register("email")), {}, {
          errorKey: (_errors$email = errors.email) === null || _errors$email === void 0 ? void 0 : _errors$email.message
        })), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_16__.jsx(_components_ui_password_input__WEBPACK_IMPORTED_MODULE_4__/* .default */ .Z, _objectSpread({
          labelKey: "forms:label-password-star",
          errorKey: (_errors$password = errors.password) === null || _errors$password === void 0 ? void 0 : _errors$password.message
        }, register("password"))), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_16__.jsxs)("div", {
          className: "flex items-center justify-center",
          children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_16__.jsxs)("div", {
            className: "flex items-center flex-shrink-0",
            children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_16__.jsxs)("label", {
              className: "switch relative inline-block w-10 cursor-pointer",
              children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_16__.jsx("input", _objectSpread({
                id: "remember",
                type: "checkbox",
                className: "opacity-0 w-0 h-0"
              }, register("remember_me"))), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_16__.jsx("span", {
                className: "bg-gray-500 absolute inset-0 transition-all duration-300 ease-in slider round"
              })]
            }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_16__.jsx("label", {
              htmlFor: "remember",
              className: "flex-shrink-0 text-sm text-heading ps-3 cursor-pointer",
              children: t("forms:label-remember-me")
            })]
          }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_16__.jsx("div", {
            className: "flex ms-auto",
            children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_16__.jsx("button", {
              type: "button",
              onClick: handleForgetPassword,
              className: "text-end text-sm text-heading ps-3 underline hover:no-underline focus:no-underline focus:outline-none",
              children: t("common:text-forgot-password")
            })
          })]
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_16__.jsx("div", {
          className: "relative",
          children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_16__.jsx(_components_ui_button__WEBPACK_IMPORTED_MODULE_5__/* .default */ .Z, {
            type: "submit",
            loading: loading,
            disabled: loading,
            className: "h-11 md:h-12 w-full mt-1.5",
            children: t("common:text-login")
          })
        })]
      })
    }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_16__.jsxs)("div", {
      className: "flex flex-col items-center justify-center relative text-sm text-heading mt-6 mb-3.5",
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_16__.jsx("hr", {
        className: "w-full border-gray-300"
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_16__.jsx("span", {
        className: "absolute -top-2.5 px-2 bg-white",
        children: t("common:text-or")
      })]
    }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_16__.jsxs)(_components_ui_button__WEBPACK_IMPORTED_MODULE_5__/* .default */ .Z, {
      loading: false,
      disabled: false,
      className: "h-11 md:h-12 w-full mt-2.5 bg-google hover:bg-googleHover",
      onClick: () => (0,next_auth_client__WEBPACK_IMPORTED_MODULE_13__.signIn)("google"),
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_16__.jsx(react_icons_im__WEBPACK_IMPORTED_MODULE_18__/* .ImGoogle2 */ .v74, {
        className: "text-sm sm:text-base me-1.5"
      }), t("common:text-login-with-google")]
    }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_16__.jsxs)("div", {
      className: "text-sm sm:text-base text-body text-center mt-5 mb-1",
      children: [t("common:text-no-account"), " ", /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_16__.jsx("button", {
        type: "button",
        className: "text-sm sm:text-base text-heading underline font-bold hover:no-underline focus:no-underline focus:outline-none",
        onClick: handleSignUp,
        children: t("common:text-register")
      })]
    })]
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (LoginForm);

/***/ })

};
;