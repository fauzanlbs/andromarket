"use strict";
exports.id = 5565;
exports.ids = [5565];
exports.modules = {

/***/ 9582:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "P": () => (/* binding */ ProductAttributes)
/* harmony export */ });
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(4058);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5282);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__);



const ProductAttributes = ({
  className = "mb-4",
  title,
  attributes,
  active,
  onClick
}) => {
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxs)("div", {
    className: className,
    children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("h3", {
      className: "text-base md:text-lg text-heading font-semibold mb-2.5 capitalize",
      children: title
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("ul", {
      className: "colors flex flex-wrap -me-3",
      children: attributes === null || attributes === void 0 ? void 0 : attributes.map(({
        id,
        value,
        meta
      }) => /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("li", {
        className: classnames__WEBPACK_IMPORTED_MODULE_0___default()("cursor-pointer rounded border border-gray-100 min-w-[36px] md:min-w-[44px] min-h-[36px] md:min-h-[44px] p-1 mb-2 md:mb-3 me-2 md:me-3 flex justify-center items-center text-heading text-xs md:text-sm uppercase font-semibold transition duration-200 ease-in-out hover:border-black", {
          "border-black": value === active,
          "px-3 md:px-3.5": title === "size"
        }),
        onClick: () => onClick({
          [title]: value
        }),
        children: title === "color" || title === 'colors' ? /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("span", {
          className: "h-full w-full rounded block",
          style: {
            backgroundColor: meta !== null && meta !== void 0 ? meta : value
          }
        }) : value
      }, `${value}-${id}`))
    })]
  });
};

/***/ }),

/***/ 4064:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "z": () => (/* binding */ generateCartItem)
/* harmony export */ });
/* harmony import */ var lodash_isEmpty__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(8718);
/* harmony import */ var lodash_isEmpty__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(lodash_isEmpty__WEBPACK_IMPORTED_MODULE_0__);

// interface Variation {
//   id: string | number;
//   title: string;
//   price: number;
//   sale_price?: number;
//   quantity: number;
//   [key: string]: unknown;
// }
function generateCartItem(item, variation) {
  const {
    id,
    name,
    slug,
    image,
    price,
    sale_price,
    quantity,
    unit
  } = item;

  if (!lodash_isEmpty__WEBPACK_IMPORTED_MODULE_0___default()(variation)) {
    return {
      id: `${id}.${variation.id}`,
      productId: id,
      name: `${name} - ${variation.title}`,
      slug,
      unit,
      stock: variation.quantity,
      price: variation.sale_price ? variation.sale_price : variation.price,
      image: image === null || image === void 0 ? void 0 : image.thumbnail,
      variationId: variation.id
    };
  }

  return {
    id,
    name,
    slug,
    unit,
    image: image === null || image === void 0 ? void 0 : image.thumbnail,
    stock: quantity,
    price: sale_price ? sale_price : price
  };
}

/***/ })

};
;