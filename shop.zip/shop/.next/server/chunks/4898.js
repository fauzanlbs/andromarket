"use strict";
exports.id = 4898;
exports.ids = [4898];
exports.modules = {

/***/ 6117:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _components_common_banner_card__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5038);
/* harmony import */ var _lib_routes__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1103);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5282);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__);




const BannerBlock = ({
  banners,
  className = "mb-12 md:mb-14 xl:mb-16"
}) => {
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx("div", {
    className: `${className} px-2.5 grid grid-cols-2 sm:grid-cols-9 gap-2 md:gap-2.5 max-w-[1920px] mx-auto`,
    children: banners === null || banners === void 0 ? void 0 : banners.map(banner => /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx(_components_common_banner_card__WEBPACK_IMPORTED_MODULE_0__/* .default */ .Z, {
      banner: banner,
      href: `${_lib_routes__WEBPACK_IMPORTED_MODULE_1__/* .ROUTES.COLLECTIONS */ .Z.COLLECTIONS}/${banner.slug}`,
      effectActive: true,
      variant: "default",
      className: banner.type === "medium" ? "col-span-full sm:col-span-5" : "col-span-1 sm:col-span-2"
    }, `banner--key${banner.id}`))
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (BannerBlock);

/***/ }),

/***/ 3723:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ brand_grid_block)
});

// EXTERNAL MODULE: ../node_modules/next/link.js
var next_link = __webpack_require__(9894);
// EXTERNAL MODULE: ../node_modules/next/image.js
var next_image = __webpack_require__(8579);
// EXTERNAL MODULE: ./src/lib/routes.ts
var routes = __webpack_require__(1103);
// EXTERNAL MODULE: external "next-i18next"
var external_next_i18next_ = __webpack_require__(8475);
// EXTERNAL MODULE: ./src/lib/filter-brands.ts
var filter_brands = __webpack_require__(7640);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(9297);
// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(5282);
;// CONCATENATED MODULE: ./src/components/common/brand-card.tsx









const BrandCard = ({
  brand
}) => {
  var _filterImages$image$, _filterImages$image, _filterImages$image$2, _filterImages$image$3, _filterImages$image2, _filterImages$image2$;

  const {
    slug,
    name,
    images
  } = brand;
  const {
    t
  } = (0,external_next_i18next_.useTranslation)("common"); // Filter images

  const filterImages = (0,filter_brands/* filterBrandImages */.z)(images, "grid-layout");
  return /*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
    href: {
      pathname: routes/* ROUTES.SEARCH */.Z.SEARCH,
      query: {
        brand: slug
      }
    },
    children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("a", {
      className: "group flex justify-center text-center relative overflow-hidden rounded-md",
      children: [/*#__PURE__*/jsx_runtime_.jsx(next_image.default, {
        src: (_filterImages$image$ = filterImages === null || filterImages === void 0 ? void 0 : (_filterImages$image = filterImages.image) === null || _filterImages$image === void 0 ? void 0 : (_filterImages$image$2 = _filterImages$image[0]) === null || _filterImages$image$2 === void 0 ? void 0 : _filterImages$image$2.original) !== null && _filterImages$image$ !== void 0 ? _filterImages$image$ : "/assets/placeholder/brand-bg.svg",
        alt: name || t("text-brand-thumbnail"),
        width: 428,
        height: 428,
        className: "rounded-md object-cover transform transition-transform ease-in-out duration-500 group-hover:rotate-6 group-hover:scale-125"
      }), /*#__PURE__*/jsx_runtime_.jsx("div", {
        className: "absolute top left bg-black w-full h-full opacity-50 transition-opacity duration-500 group-hover:opacity-80"
      }), /*#__PURE__*/jsx_runtime_.jsx("div", {
        className: "absolute top left h-full w-full flex items-center justify-center p-8",
        children: /*#__PURE__*/jsx_runtime_.jsx("img", {
          src: (_filterImages$image$3 = filterImages === null || filterImages === void 0 ? void 0 : (_filterImages$image2 = filterImages.image) === null || _filterImages$image2 === void 0 ? void 0 : (_filterImages$image2$ = _filterImages$image2[1]) === null || _filterImages$image2$ === void 0 ? void 0 : _filterImages$image2$.original) !== null && _filterImages$image$3 !== void 0 ? _filterImages$image$3 : "/assets/placeholder/brand-bg.svg",
          alt: name || t("text-brand-thumbnail"),
          className: "flex-shrink-0"
        })
      })]
    })
  });
};

/* harmony default export */ const brand_card = (BrandCard);
// EXTERNAL MODULE: ./src/components/common/section-header.tsx
var section_header = __webpack_require__(7125);
// EXTERNAL MODULE: external "react-content-loader"
var external_react_content_loader_ = __webpack_require__(9081);
var external_react_content_loader_default = /*#__PURE__*/__webpack_require__.n(external_react_content_loader_);
;// CONCATENATED MODULE: ./src/components/ui/loaders/brand-card-loader.tsx
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }




const BrandCardLoader = props => /*#__PURE__*/jsx_runtime_.jsx((external_react_content_loader_default()), _objectSpread(_objectSpread({
  speed: 2,
  width: 423,
  height: 423,
  viewBox: "0 0 423 423",
  backgroundColor: "#f3f3f3",
  foregroundColor: "#ecebeb",
  className: "w-full h-auto"
}, props), {}, {
  children: /*#__PURE__*/jsx_runtime_.jsx("rect", {
    x: "0",
    y: "0",
    rx: "6",
    ry: "6",
    width: "423",
    height: "423"
  })
}));

/* harmony default export */ const brand_card_loader = (BrandCardLoader);
// EXTERNAL MODULE: ./src/components/ui/alert.tsx
var ui_alert = __webpack_require__(5013);
// EXTERNAL MODULE: ./src/framework/rest/brand/brands.query.tsx
var brands_query = __webpack_require__(4412);
// EXTERNAL MODULE: external "lodash/isEmpty"
var isEmpty_ = __webpack_require__(8718);
var isEmpty_default = /*#__PURE__*/__webpack_require__.n(isEmpty_);
// EXTERNAL MODULE: ./src/components/404/not-found-item.tsx
var not_found_item = __webpack_require__(6857);
;// CONCATENATED MODULE: ./src/containers/brand-grid-block.tsx













const BrandGridBlock = ({
  className = "mb-12 md:mb-14 xl:mb-16",
  sectionHeading
}) => {
  var _data$pages, _data$pages$, _data$pages2, _data$pages2$, _gridBrands$length;

  const {
    t
  } = (0,external_next_i18next_.useTranslation)();
  const {
    data,
    isLoading: loading,
    error
  } = (0,brands_query/* useBrandsQuery */.ac)({});

  if (!loading && isEmpty_default()(data === null || data === void 0 ? void 0 : (_data$pages = data.pages) === null || _data$pages === void 0 ? void 0 : (_data$pages$ = _data$pages[0]) === null || _data$pages$ === void 0 ? void 0 : _data$pages$.data)) {
    return /*#__PURE__*/jsx_runtime_.jsx(not_found_item/* default */.Z, {
      text: t("text-no-brands-found")
    });
  } // Filter brands for grid layout


  const gridBrands = (0,filter_brands/* filterBrands */.b)(data === null || data === void 0 ? void 0 : (_data$pages2 = data.pages) === null || _data$pages2 === void 0 ? void 0 : (_data$pages2$ = _data$pages2[0]) === null || _data$pages2$ === void 0 ? void 0 : _data$pages2$.data, "grid-layout");
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
    className: className,
    children: [/*#__PURE__*/jsx_runtime_.jsx(section_header/* default */.Z, {
      sectionHeading: sectionHeading
    }), error ? /*#__PURE__*/jsx_runtime_.jsx(ui_alert/* default */.Z, {
      message: error === null || error === void 0 ? void 0 : error.message
    }) : /*#__PURE__*/jsx_runtime_.jsx("div", {
      className: "grid grid-cols-2 sm:grid-cols-4 gap-2.5 md:gap-3 lg:gap-5 xl:gap-7",
      children: loading ? Array.from({
        length: (_gridBrands$length = gridBrands === null || gridBrands === void 0 ? void 0 : gridBrands.length) !== null && _gridBrands$length !== void 0 ? _gridBrands$length : 0
      }).map((_, idx) => /*#__PURE__*/jsx_runtime_.jsx(brand_card_loader, {
        uniqueKey: `top-brand-${idx}`
      }, idx)) : gridBrands === null || gridBrands === void 0 ? void 0 : gridBrands.map(brand => /*#__PURE__*/jsx_runtime_.jsx(brand_card, {
        brand: brand
      }, `brand--key${brand.id}`))
    })]
  });
};

/* harmony default export */ const brand_grid_block = (BrandGridBlock);

/***/ })

};
;