"use strict";
exports.id = 7114;
exports.ids = [7114];
exports.modules = {

/***/ 6857:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9297);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5282);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__);



const NotFoundItem = ({
  text
}) => /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("div", {
  className: "shadow-lg rounded border border-gray-300 p-5 mb-12 md:mb-14 xl:mb-16",
  children: text
});

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (NotFoundItem);

/***/ }),

/***/ 5038:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _components_ui_link__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1420);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8579);
/* harmony import */ var _utils_use_window_size__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3396);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(4058);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5282);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__);







function getImage(deviceWidth, imgObj) {
  return deviceWidth < 480 ? imgObj.mobile : imgObj.desktop;
}

const BannerCard = ({
  banner,
  className,
  variant = "rounded",
  effectActive = false,
  classNameInner,
  href
}) => {
  const {
    width
  } = (0,_utils_use_window_size__WEBPACK_IMPORTED_MODULE_2__/* .useWindowSize */ .i)();
  const {
    title,
    image
  } = banner;
  const selectedImage = getImage(width, image);
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx("div", {
    className: classnames__WEBPACK_IMPORTED_MODULE_3___default()("mx-auto", className),
    children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsxs)(_components_ui_link__WEBPACK_IMPORTED_MODULE_0__/* .default */ .Z, {
      href: href,
      className: classnames__WEBPACK_IMPORTED_MODULE_3___default()("h-full group flex justify-center relative overflow-hidden", classNameInner),
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx(next_image__WEBPACK_IMPORTED_MODULE_1__.default, {
        src: selectedImage.url,
        width: selectedImage.width,
        height: selectedImage.height,
        alt: title,
        quality: 100,
        className: classnames__WEBPACK_IMPORTED_MODULE_3___default()("bg-gray-300 object-cover w-full", {
          "rounded-md": variant === "rounded"
        })
      }), effectActive && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_4__.jsx("div", {
        className: "absolute top-0 -start-full h-full w-1/2 z-5 block transform -skew-x-12 bg-gradient-to-r from-transparent to-white opacity-40 group-hover:animate-shine"
      })]
    })
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (BannerCard);

/***/ }),

/***/ 3765:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _components_ui_link__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1420);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8579);
/* harmony import */ var _components_ui_text__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(4068);
/* harmony import */ var react_icons_fa__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(7228);
/* harmony import */ var next_i18next__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8475);
/* harmony import */ var next_i18next__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_i18next__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9297);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _lib_filter_brands__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(7640);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(5282);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__);











const Card = ({
  item,
  variant = "circle",
  size = "small",
  effectActive = false,
  href
}) => {
  var _ref, _item$image$original, _item$image, _filterBrandImages, _filterBrandImages$im, _filterBrandImages$im2;

  const {
    name
  } = item !== null && item !== void 0 ? item : {};
  const imageSize = size === "small" && 180 || size === "medium" && 198;
  const placeholderImage = `/assets/placeholder/card-${size}.svg`;
  const {
    t
  } = (0,next_i18next__WEBPACK_IMPORTED_MODULE_3__.useTranslation)("common");
  const image = (_ref = (_item$image$original = item === null || item === void 0 ? void 0 : (_item$image = item.image) === null || _item$image === void 0 ? void 0 : _item$image.original) !== null && _item$image$original !== void 0 ? _item$image$original : (_filterBrandImages = (0,_lib_filter_brands__WEBPACK_IMPORTED_MODULE_6__/* .filterBrandImages */ .z)(item === null || item === void 0 ? void 0 : item.images, "slider-layout")) === null || _filterBrandImages === void 0 ? void 0 : (_filterBrandImages$im = _filterBrandImages.image) === null || _filterBrandImages$im === void 0 ? void 0 : (_filterBrandImages$im2 = _filterBrandImages$im[0]) === null || _filterBrandImages$im2 === void 0 ? void 0 : _filterBrandImages$im2.original) !== null && _ref !== void 0 ? _ref : placeholderImage;
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxs)(_components_ui_link__WEBPACK_IMPORTED_MODULE_0__/* .default */ .Z, {
    href: href,
    className: "group flex justify-center text-center flex-col",
    children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxs)("div", {
      className: `relative inline-flex mb-3.5 md:mb-4 lg:mb-5 xl:mb-6 mx-auto ${variant === "rounded" ? "rounded-md" : "rounded-full"}`,
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx("div", {
        className: "flex",
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx(next_image__WEBPACK_IMPORTED_MODULE_1__.default, {
          src: image,
          alt: name || t("text-card-thumbnail"),
          width: imageSize,
          height: imageSize,
          quality: 100,
          className: `object-cover bg-gray-300 ${variant === "rounded" ? "rounded-md" : "rounded-full"}`
        })
      }), effectActive === true && /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.Fragment, {
        children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx("div", {
          className: `absolute top left bg-black w-full h-full opacity-0 transition-opacity duration-300 group-hover:opacity-30 ${variant === "rounded" ? "rounded-md" : "rounded-full"}`
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx("div", {
          className: "absolute top left h-full w-full flex items-center justify-center",
          children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx(react_icons_fa__WEBPACK_IMPORTED_MODULE_7__/* .FaLink */ .gjK, {
            className: "text-white text-base sm:text-xl lg:text-2xl xl:text-3xl transform opacity-0 scale-0 transition-all duration-300 ease-in-out group-hover:opacity-100 group-hover:scale-100"
          })
        })]
      })]
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx(_components_ui_text__WEBPACK_IMPORTED_MODULE_2__/* .default */ .Z, {
      variant: "heading",
      className: "capitalize",
      children: name
    })]
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Card);

/***/ }),

/***/ 7195:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(8579);
/* harmony import */ var _components_ui_text__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(4068);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(4058);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _components_ui_link__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1420);
/* harmony import */ var next_i18next__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(8475);
/* harmony import */ var next_i18next__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_i18next__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(5282);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__);







const data = {
  title: "app-heading",
  subTitle: "app-sub-heading",
  appImage: "/assets/images/app.png",
  appButtons: [{
    id: 1,
    slug: "/#",
    altText: "button-app-store",
    appButton: "/assets/images/app-store.svg",
    buttonWidth: 209,
    buttonHeight: 60
  }, {
    id: 2,
    slug: "/#",
    altText: "button-play-store",
    appButton: "/assets/images/play-store.svg",
    buttonWidth: 209,
    buttonHeight: 60
  }]
};

const DownloadApps = ({
  className
}) => {
  const {
    appButtons,
    title,
    subTitle,
    appImage
  } = data;
  const {
    t
  } = (0,next_i18next__WEBPACK_IMPORTED_MODULE_4__.useTranslation)("common");
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxs)("div", {
    className: classnames__WEBPACK_IMPORTED_MODULE_2___default()("flex justify-between items-end rounded-lg bg-gray-200 pt-5 md:pt-8 lg:pt-10 xl:pt-14 px-6 md:px-12 lg:px-20 2xl:px-24 3xl:px-36", className),
    children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx("div", {
      className: "flex-shrink-0 w-full sm:w-60 md:w-96 lg:w-auto lg:max-w-lg xl:max-w-xl lg:flex lg:items-center pb-5 md:pb-8 lg:pb-12 xl:pb-16",
      children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxs)("div", {
        className: "py-4 md:py-6 xl:py-8 text-center sm:text-start",
        children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx(_components_ui_text__WEBPACK_IMPORTED_MODULE_1__/* .default */ .Z, {
          variant: "mediumHeading",
          className: "-mt-1 mb-2 md:mb-3 lg:mb-3.5 xl:mb-4",
          children: t(`${title}`)
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx("h2", {
          className: "text-heading text-md sm:text-xl md:text-3xl xl:text-4xl 2xl:text-5xl font-normal leading-7 sm:leading-8 md:leading-snug xl:leading-relaxed 2xl:leading-snug mb-6 md:mb-8 lg:mb-9 xl:mb-12 2xl:mb-14 lg:pe-20 2xl:pe-0",
          dangerouslySetInnerHTML: {
            __html: t(`${subTitle}`)
          }
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx("div", {
          className: "flex justify-center sm:justify-start space-s-2 md:space-s-3 px-6 sm:px-0",
          children: appButtons === null || appButtons === void 0 ? void 0 : appButtons.map(item => /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx(_components_ui_link__WEBPACK_IMPORTED_MODULE_3__/* .default */ .Z, {
            href: item.slug,
            className: "inline-flex transition duration-200 ease-in hover:box-shadow hover:opacity-80",
            children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx("img", {
              src: item.appButton,
              alt: t(`${item.altText}`),
              className: "w-36 lg:w-44 xl:w-auto",
              width: item.buttonWidth,
              height: item.buttonHeight
            })
          }, item.id))
        })]
      })
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx("div", {
      className: "hidden sm:flex items-end ps-4 -me-0.5 2xl:-me-1.5 w-60 md:w-72 lg:w-96 xl:w-auto",
      children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx(next_image__WEBPACK_IMPORTED_MODULE_0__.default, {
        src: appImage,
        alt: t("text-app-thumbnail"),
        width: 375,
        height: 430
      })
    })]
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (DownloadApps);

/***/ }),

/***/ 7125:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _components_ui_text__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(4068);
/* harmony import */ var _components_ui_link__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1420);
/* harmony import */ var next_i18next__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8475);
/* harmony import */ var next_i18next__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_i18next__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5282);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__);






const SectionHeader = ({
  sectionHeading = "text-section-title",
  categorySlug,
  className = "pb-0.5 mb-4 md:mb-5 lg:mb-6 2xl:mb-7 3xl:mb-8"
}) => {
  const {
    t
  } = (0,next_i18next__WEBPACK_IMPORTED_MODULE_2__.useTranslation)("common");
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsxs)("div", {
    className: `flex items-center justify-between -mt-2 lg:-mt-2.5 ${className}`,
    children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx(_components_ui_text__WEBPACK_IMPORTED_MODULE_0__/* .default */ .Z, {
      variant: "mediumHeading",
      children: t(`${sectionHeading}`)
    }), categorySlug && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_3__.jsx(_components_ui_link__WEBPACK_IMPORTED_MODULE_1__/* .default */ .Z, {
      href: categorySlug,
      className: "text-xs lg:text-sm xl:text-base text-heading mt-0.5 lg:mt-1",
      children: t("text-see-all-product")
    })]
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (SectionHeader);

/***/ }),

/***/ 7063:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(8579);
/* harmony import */ var _components_ui_text__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(4068);
/* harmony import */ var _components_ui_button__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7993);
/* harmony import */ var react_icons_io5__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(5936);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(4058);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var next_i18next__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(8475);
/* harmony import */ var next_i18next__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_i18next__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _settings_site_settings__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(5278);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(5282);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__);









const data = {
  title: "support-heading",
  description: "support-sub-heading",
  buttonText: "button-chat-services",
  supportImage: "/assets/images/support.png"
};

const Support = ({
  className
}) => {
  const {
    title,
    description,
    supportImage,
    buttonText
  } = data;
  const {
    t
  } = (0,next_i18next__WEBPACK_IMPORTED_MODULE_4__.useTranslation)("common");
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxs)("div", {
    className: classnames__WEBPACK_IMPORTED_MODULE_3___default()("my-8 md:my-12 lg:my-16 xl:my-20 3xl:my-24 pb-5 lg:pb-3.5 2xl:pb-5 pt-3 lg:pt-1.5 2xl:pt-2 3xl:pt-3 text-center", className),
    children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxs)("div", {
      className: "max-w-md mx-auto mb-4 md:mb-5 xl:mb-8 2xl:mb-10 3xl:mb-12",
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx(_components_ui_text__WEBPACK_IMPORTED_MODULE_1__/* .default */ .Z, {
        variant: "mediumHeading",
        className: "mb-2 md:mb-3 lg:mb-3.5",
        children: t(`${title}`)
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx("p", {
        className: "text-body text-xs md:text-sm leading-6 md:leading-7",
        children: t(`${description}`)
      })]
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx("div", {
      className: "mb-2.5 md:mb-0 xl:mb-2 2xl:mb-4 3xl:mb-6 md:px-20 lg:px-40 xl:px-0",
      children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx(next_image__WEBPACK_IMPORTED_MODULE_0__.default, {
        src: supportImage,
        alt: t("text-support-thumbnail"),
        width: 870,
        height: 300
      })
    }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx(_components_ui_button__WEBPACK_IMPORTED_MODULE_2__/* .default */ .Z, {
      children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsxs)("a", {
        href: _settings_site_settings__WEBPACK_IMPORTED_MODULE_5__/* .siteSettings */ .U !== null && _settings_site_settings__WEBPACK_IMPORTED_MODULE_5__/* .siteSettings */ .U !== void 0 && _settings_site_settings__WEBPACK_IMPORTED_MODULE_5__/* .siteSettings.chatButtonUrl */ .U.chatButtonUrl ? _settings_site_settings__WEBPACK_IMPORTED_MODULE_5__/* .siteSettings */ .U === null || _settings_site_settings__WEBPACK_IMPORTED_MODULE_5__/* .siteSettings */ .U === void 0 ? void 0 : _settings_site_settings__WEBPACK_IMPORTED_MODULE_5__/* .siteSettings.chatButtonUrl */ .U.chatButtonUrl : "#",
        target: "_blank",
        className: "flex",
        children: [t(`${buttonText}`), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_6__.jsx(react_icons_io5__WEBPACK_IMPORTED_MODULE_7__/* .IoChatbubbleEllipsesOutline */ .rIi, {
          className: "ms-2 text-lg md:text-xl"
        })]
      })
    })]
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Support);

/***/ }),

/***/ 4584:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ NewArrivalsProductFeed)
/* harmony export */ });
/* harmony import */ var _containers_products_block__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(1402);
/* harmony import */ var _framework_products_products_query__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2317);
/* harmony import */ var next_i18next__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8475);
/* harmony import */ var next_i18next__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_i18next__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var lodash_isEmpty__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8718);
/* harmony import */ var lodash_isEmpty__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(lodash_isEmpty__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _components_404_not_found_item__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6857);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(5282);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__);






function NewArrivalsProductFeed() {
  var _products$pages;

  const {
    t
  } = (0,next_i18next__WEBPACK_IMPORTED_MODULE_2__.useTranslation)();
  const {
    data: products,
    isLoading: loading,
    error
  } = (0,_framework_products_products_query__WEBPACK_IMPORTED_MODULE_1__/* .useProductsQuery */ .kN)({
    limit: 10,
    orderBy: "created_at",
    sortedBy: "DESC"
  });

  if (!loading && lodash_isEmpty__WEBPACK_IMPORTED_MODULE_3___default()(products === null || products === void 0 ? void 0 : (_products$pages = products.pages) === null || _products$pages === void 0 ? void 0 : _products$pages[0].data)) {
    return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx(_components_404_not_found_item__WEBPACK_IMPORTED_MODULE_4__/* .default */ .Z, {
      text: t("text-no-products-found")
    });
  }

  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx(_containers_products_block__WEBPACK_IMPORTED_MODULE_0__/* .default */ .Z, {
    sectionHeading: "text-new-arrivals",
    products: products === null || products === void 0 ? void 0 : products.pages[0].data,
    loading: loading,
    error: error === null || error === void 0 ? void 0 : error.message,
    uniqueKey: "new-arrivals"
  });
}

/***/ }),

/***/ 1802:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_content_loader__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9081);
/* harmony import */ var react_content_loader__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_content_loader__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5282);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__);
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }





const CardRoundedLoader = props => /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxs)((react_content_loader__WEBPACK_IMPORTED_MODULE_0___default()), _objectSpread(_objectSpread({
  speed: 2,
  width: 197,
  height: 249,
  viewBox: "0 0 197 249",
  backgroundColor: "#f3f3f3",
  foregroundColor: "#ecebeb",
  className: "w-full h-auto"
}, props), {}, {
  children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("rect", {
    x: "34",
    y: "230",
    rx: "3",
    ry: "3",
    width: "110",
    height: "10"
  }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx("rect", {
    x: "0",
    y: "0",
    rx: "6",
    ry: "6",
    width: "197",
    height: "197"
  })]
}));

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (CardRoundedLoader);

/***/ }),

/***/ 1402:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9297);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _components_common_section_header__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7125);
/* harmony import */ var _components_product_product_card__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(135);
/* harmony import */ var _components_ui_loaders_product_feed_loader__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(4636);
/* harmony import */ var _components_ui_alert__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5013);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(5282);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__);








const ProductsBlock = ({
  sectionHeading,
  categorySlug,
  className = "mb-9 md:mb-9 lg:mb-10 xl:mb-12",
  products,
  loading,
  error,
  uniqueKey
}) => {
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsxs)("div", {
    className: className,
    children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx(_components_common_section_header__WEBPACK_IMPORTED_MODULE_1__/* .default */ .Z, {
      sectionHeading: sectionHeading,
      categorySlug: categorySlug
    }), error ? /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx(_components_ui_alert__WEBPACK_IMPORTED_MODULE_4__/* .default */ .Z, {
      message: error
    }) : /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx("div", {
      className: "grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 2xl:grid-cols-5 gap-x-3 md:gap-x-5 xl:gap-x-7 gap-y-3 xl:gap-y-5 2xl:gap-y-8",
      children: loading && !(products !== null && products !== void 0 && products.length) ? /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx(_components_ui_loaders_product_feed_loader__WEBPACK_IMPORTED_MODULE_3__/* .default */ .Z, {
        limit: 10,
        uniqueKey: uniqueKey
      }) : products === null || products === void 0 ? void 0 : products.map(product => /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_5__.jsx(_components_product_product_card__WEBPACK_IMPORTED_MODULE_2__/* .default */ .Z, {
        product: product,
        imgWidth: 340,
        imgHeight: 440,
        variant: "grid"
      }, `product--key${product.id}`))
    })]
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ProductsBlock);

/***/ }),

/***/ 7640:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "b": () => (/* binding */ filterBrands),
/* harmony export */   "z": () => (/* binding */ filterBrandImages)
/* harmony export */ });
/**
 * Helper methods to filter brands
 *
 * @param brands
 * @param layout
 */
const filterBrands = (brands, layout) => {
  if (!brands) {
    return [];
  }

  const filterBrands = [];
  brands === null || brands === void 0 ? void 0 : brands.map(brand => {
    var _brand$images;

    brand === null || brand === void 0 ? void 0 : (_brand$images = brand.images) === null || _brand$images === void 0 ? void 0 : _brand$images.map(image => {
      if (image.key === layout) {
        filterBrands.push(brand);
        return false;
      }
    });
  });
  return filterBrands;
};
const filterBrandImages = (images, layout) => {
  return images === null || images === void 0 ? void 0 : images.find(image => image.key === layout);
};

/***/ })

};
;