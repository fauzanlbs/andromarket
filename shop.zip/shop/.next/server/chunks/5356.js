"use strict";
exports.id = 5356;
exports.ids = [5356];
exports.modules = {

/***/ 5356:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9297);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _components_ui_logo__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(4386);
/* harmony import */ var _components_ui_alert__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5013);
/* harmony import */ var _contexts_ui_context__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(4580);
/* harmony import */ var _framework_auth_auth_query__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6838);
/* harmony import */ var next_dynamic__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(5218);
/* harmony import */ var next_i18next__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(8475);
/* harmony import */ var next_i18next__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(next_i18next__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(6731);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _lib_routes__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(1103);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(5282);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__);













const EnterEmailView = (0,next_dynamic__WEBPACK_IMPORTED_MODULE_5__.default)(() => __webpack_require__.e(/* import() */ 1153).then(__webpack_require__.bind(__webpack_require__, 1153)), {
  loadableGenerated: {
    webpack: () => [/*require.resolve*/(1153)],
    modules: ["../components/auth/forget-password/forget-password.tsx -> " + "./enter-email-view"]
  }
});
const EnterTokenView = (0,next_dynamic__WEBPACK_IMPORTED_MODULE_5__.default)(() => __webpack_require__.e(/* import() */ 5986).then(__webpack_require__.bind(__webpack_require__, 9814)), {
  loadableGenerated: {
    webpack: () => [/*require.resolve*/(9814)],
    modules: ["../components/auth/forget-password/forget-password.tsx -> " + "./enter-token-view"]
  }
});
const EnterNewPasswordView = (0,next_dynamic__WEBPACK_IMPORTED_MODULE_5__.default)(() => Promise.all(/* import() */[__webpack_require__.e(1097), __webpack_require__.e(5090), __webpack_require__.e(414)]).then(__webpack_require__.bind(__webpack_require__, 414)), {
  loadableGenerated: {
    webpack: () => [/*require.resolve*/(414)],
    modules: ["../components/auth/forget-password/forget-password.tsx -> " + "./enter-new-password-view"]
  }
});

const ForgotPassword = ({
  layout = "modal"
}) => {
  const router = (0,next_router__WEBPACK_IMPORTED_MODULE_7__.useRouter)();
  const {
    t
  } = (0,next_i18next__WEBPACK_IMPORTED_MODULE_6__.useTranslation)();
  const {
    setModalView,
    closeModal
  } = (0,_contexts_ui_context__WEBPACK_IMPORTED_MODULE_3__/* .useUI */ .l8)();
  const {
    mutate: forgetPassword,
    isLoading
  } = (0,_framework_auth_auth_query__WEBPACK_IMPORTED_MODULE_4__/* .useForgetPasswordMutation */ .xy)();
  const {
    mutate: verifyToken,
    isLoading: verifying
  } = (0,_framework_auth_auth_query__WEBPACK_IMPORTED_MODULE_4__/* .useVerifyForgetPasswordTokenMutation */ .AV)();
  const {
    mutate: resetPassword,
    isLoading: resetting
  } = (0,_framework_auth_auth_query__WEBPACK_IMPORTED_MODULE_4__/* .useResetPasswordMutation */ .gL)();
  const {
    0: errorMsg,
    1: setErrorMsg
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)("");
  const {
    0: verifiedEmail,
    1: setVerifiedEmail
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)("");
  const {
    0: verifiedToken,
    1: setVerifiedToken
  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)("");

  function handleEmailSubmit({
    email
  }) {
    forgetPassword({
      email
    }, {
      onSuccess: data => {
        if (data.success) {
          setVerifiedEmail(email);
        } else {
          setErrorMsg(data === null || data === void 0 ? void 0 : data.message);
        }
      }
    });
  }

  function handleTokenSubmit({
    token
  }) {
    verifyToken({
      email: verifiedEmail,
      token
    }, {
      onSuccess: data => {
        if (data.success) {
          setVerifiedToken(token);
        } else {
          setErrorMsg(data === null || data === void 0 ? void 0 : data.message);
        }
      }
    });
  }

  function handleResetPassword({
    password
  }) {
    resetPassword({
      email: verifiedEmail,
      token: verifiedToken,
      password
    }, {
      onSuccess: data => {
        if (data.success) {
          if (layout === "page") {
            router.push(_lib_routes__WEBPACK_IMPORTED_MODULE_8__/* .ROUTES.LOGIN */ .Z.LOGIN);
          } else {
            setModalView("LOGIN_VIEW");
          }
        } else {
          setErrorMsg(data === null || data === void 0 ? void 0 : data.message);
        }
      }
    });
  }

  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxs)("div", {
    className: "py-6 px-5 sm:p-8 bg-white mx-auto rounded-lg w-full sm:w-96 md:w-450px border border-gray-300",
    children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxs)("div", {
      className: "text-center mb-9 pt-2.5",
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx("div", {
        onClick: closeModal,
        children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx(_components_ui_logo__WEBPACK_IMPORTED_MODULE_1__/* .default */ .Z, {})
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx("p", {
        className: "text-sm md:text-base text-body mt-3 sm:mt-4 mb-8 sm:mb-10",
        children: t("common:forgot-password-helper")
      })]
    }), errorMsg && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx(_components_ui_alert__WEBPACK_IMPORTED_MODULE_2__/* .default */ .Z, {
      variant: "error",
      message: errorMsg,
      className: "mb-6",
      closeable: true,
      onClose: () => setErrorMsg("")
    }), !verifiedEmail && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx(EnterEmailView, {
      loading: isLoading,
      onSubmit: handleEmailSubmit
    }), verifiedEmail && !verifiedToken && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx(EnterTokenView, {
      loading: verifying,
      onSubmit: handleTokenSubmit
    }), verifiedEmail && verifiedToken && /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx(EnterNewPasswordView, {
      loading: resetting,
      onSubmit: handleResetPassword
    }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxs)("div", {
      className: "flex flex-col items-center justify-center relative text-sm text-heading mt-8 sm:mt-10 mb-6 sm:mb-7",
      children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx("hr", {
        className: "w-full border-gray-300"
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx("span", {
        className: "absolute -top-2.5 px-2 bg-white",
        children: t("common:text-or")
      })]
    }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsxs)("div", {
      className: "text-sm sm:text-base text-body text-center",
      children: [t("common:text-back-to"), " ", /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_9__.jsx("button", {
        type: "button",
        className: "text-sm sm:text-base text-heading underline font-bold hover:no-underline focus:outline-none",
        onClick: () => setModalView("LOGIN_VIEW"),
        children: t("common:text-login")
      })]
    })]
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ForgotPassword);

/***/ })

};
;