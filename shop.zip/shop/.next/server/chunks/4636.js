"use strict";
exports.id = 4636;
exports.ids = [4636];
exports.modules = {

/***/ 4636:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ product_feed_loader)
});

// EXTERNAL MODULE: external "react-content-loader"
var external_react_content_loader_ = __webpack_require__(9081);
var external_react_content_loader_default = /*#__PURE__*/__webpack_require__.n(external_react_content_loader_);
// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(5282);
;// CONCATENATED MODULE: ./src/components/ui/loaders/product-card-loader.tsx
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }





const ProductCardLoader = props => /*#__PURE__*/(0,jsx_runtime_.jsxs)((external_react_content_loader_default()), _objectSpread(_objectSpread({
  speed: 2,
  width: 334,
  height: 545,
  viewBox: "0 0 334 545",
  backgroundColor: "#f3f3f3",
  foregroundColor: "#ecebeb",
  className: "w-full h-auto"
}, props), {}, {
  children: [/*#__PURE__*/jsx_runtime_.jsx("rect", {
    x: "15",
    y: "453",
    rx: "3",
    ry: "3",
    width: "180",
    height: "8"
  }), /*#__PURE__*/jsx_runtime_.jsx("rect", {
    x: "15",
    y: "482",
    rx: "3",
    ry: "3",
    width: "280",
    height: "6"
  }), /*#__PURE__*/jsx_runtime_.jsx("rect", {
    x: "15",
    y: "515",
    rx: "3",
    ry: "3",
    width: "80",
    height: "8"
  }), /*#__PURE__*/jsx_runtime_.jsx("rect", {
    x: "0",
    y: "0",
    rx: "6",
    ry: "6",
    width: "334",
    height: "430"
  })]
}));

/* harmony default export */ const product_card_loader = (ProductCardLoader);
;// CONCATENATED MODULE: ./src/components/ui/loaders/product-feed-loader.tsx




const ProductFeedLoader = ({
  limit = 5,
  uniqueKey = "product"
}) => {
  return /*#__PURE__*/jsx_runtime_.jsx(jsx_runtime_.Fragment, {
    children: Array.from({
      length: limit
    }).map((_, idx) => /*#__PURE__*/jsx_runtime_.jsx(product_card_loader, {
      uniqueKey: `${uniqueKey}-${idx}`
    }, idx))
  });
};

/* harmony default export */ const product_feed_loader = (ProductFeedLoader);

/***/ })

};
;