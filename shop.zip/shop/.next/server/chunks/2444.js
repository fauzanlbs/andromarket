exports.id = 2444;
exports.ids = [2444];
exports.modules = {

/***/ 2444:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ order_details)
});

// EXTERNAL MODULE: ./src/lib/use-price.ts
var use_price = __webpack_require__(7259);
// EXTERNAL MODULE: ./src/lib/format-address.ts
var format_address = __webpack_require__(2528);
// EXTERNAL MODULE: ./src/components/ui/error-message.tsx
var error_message = __webpack_require__(3315);
// EXTERNAL MODULE: ./src/components/ui/loaders/spinner/spinner.tsx
var spinner = __webpack_require__(9204);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(9297);
// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(5282);
;// CONCATENATED MODULE: ./src/components/icons/checkmark.tsx
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }



const CheckMark = _ref => {
  let props = Object.assign({}, _ref);
  return /*#__PURE__*/jsx_runtime_.jsx("svg", _objectSpread(_objectSpread({
    xmlns: "http://www.w3.org/2000/svg",
    width: "20.894",
    height: "16",
    viewBox: "0 0 20.894 16"
  }, props), {}, {
    children: /*#__PURE__*/jsx_runtime_.jsx("path", {
      "data-name": "_ionicons_svg_ios-checkmark (3)",
      d: "M169.184,175.473l-1.708-1.756a.367.367,0,0,0-.272-.116.352.352,0,0,0-.272.116l-11.837,11.925-4.308-4.308a.375.375,0,0,0-.543,0l-1.727,1.727a.387.387,0,0,0,0,.553l5.434,5.434a1.718,1.718,0,0,0,1.135.553,1.8,1.8,0,0,0,1.126-.534h.01l12.973-13.041A.415.415,0,0,0,169.184,175.473Z",
      transform: "translate(-148.4 -173.6)",
      fill: "currentColor"
    })
  }));
};
// EXTERNAL MODULE: external "classnames"
var external_classnames_ = __webpack_require__(4058);
var external_classnames_default = /*#__PURE__*/__webpack_require__.n(external_classnames_);
// EXTERNAL MODULE: ./src/components/ui/scrollbar.tsx
var scrollbar = __webpack_require__(1859);
// EXTERNAL MODULE: ./src/components/ui/progress-box/progress-box.module.css
var progress_box_module = __webpack_require__(1919);
var progress_box_module_default = /*#__PURE__*/__webpack_require__.n(progress_box_module);
;// CONCATENATED MODULE: ./src/components/ui/progress-box/progress-box.tsx







const ProgressBox = ({
  status,
  data
}) => {
  return /*#__PURE__*/jsx_runtime_.jsx(scrollbar/* default */.Z, {
    className: "w-full h-full",
    options: {
      scrollbars: {
        autoHide: "never"
      }
    },
    children: /*#__PURE__*/jsx_runtime_.jsx("div", {
      className: "flex flex-col py-7 md:items-start md:justify-start w-full md:flex-row",
      children: data === null || data === void 0 ? void 0 : data.map(item => /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: (progress_box_module_default()).progress_container,
        children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          className: external_classnames_default()((progress_box_module_default()).progress_wrapper, status >= item.serial ? (progress_box_module_default()).checked : ""),
          children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
            className: (progress_box_module_default()).status_wrapper,
            children: status >= item.serial ? /*#__PURE__*/jsx_runtime_.jsx("div", {
              className: "w-3 h-4",
              children: /*#__PURE__*/jsx_runtime_.jsx(CheckMark, {
                className: "w-full"
              })
            }) : item.serial
          }), /*#__PURE__*/jsx_runtime_.jsx("div", {
            className: (progress_box_module_default()).bar
          })]
        }), /*#__PURE__*/jsx_runtime_.jsx("div", {
          className: "flex flex-col items-start ms-5 md:items-center md:ms-0",
          children: item && /*#__PURE__*/jsx_runtime_.jsx("span", {
            className: "text-base text-body-dark capitalize font-semibold text-start md:text-center md:px-2",
            children: item === null || item === void 0 ? void 0 : item.name
          })
        })]
      }, item.id))
    })
  });
};

/* harmony default export */ const progress_box = (ProgressBox);
// EXTERNAL MODULE: ./src/framework/rest/orders/orders.query.ts
var orders_query = __webpack_require__(2702);
;// CONCATENATED MODULE: ./src/framework/rest/orders/status.tsx






const OrderStatus = ({
  status
}) => {
  var _data$order_statuses;

  const {
    data,
    isLoading: loading,
    error
  } = (0,orders_query/* useOrderStatusesQuery */.Qk)();
  if (loading) return /*#__PURE__*/jsx_runtime_.jsx(spinner/* default */.Z, {
    showText: false
  });
  if (error) return /*#__PURE__*/jsx_runtime_.jsx(error_message/* default */.Z, {
    message: error.message
  });
  return /*#__PURE__*/jsx_runtime_.jsx(progress_box, {
    data: data === null || data === void 0 ? void 0 : (_data$order_statuses = data.order_statuses) === null || _data$order_statuses === void 0 ? void 0 : _data$order_statuses.data,
    status: status
  });
};

/* harmony default export */ const orders_status = (OrderStatus);
// EXTERNAL MODULE: external "next-i18next"
var external_next_i18next_ = __webpack_require__(8475);
// EXTERNAL MODULE: ./src/components/ui/link.tsx
var ui_link = __webpack_require__(1420);
// EXTERNAL MODULE: ./src/lib/routes.ts
var routes = __webpack_require__(1103);
// EXTERNAL MODULE: ./src/components/icons/eye-icon.tsx
var eye_icon = __webpack_require__(1097);
// EXTERNAL MODULE: ./src/components/orders/order-items.tsx
var order_items = __webpack_require__(6014);
// EXTERNAL MODULE: external "lodash/isEmpty"
var isEmpty_ = __webpack_require__(8718);
var isEmpty_default = /*#__PURE__*/__webpack_require__.n(isEmpty_);
// EXTERNAL MODULE: ./src/components/404/not-found.tsx
var not_found = __webpack_require__(2973);
;// CONCATENATED MODULE: ./src/components/orders/order-details.tsx














const OrderDetails = ({
  order
}) => {
  const {
    t
  } = (0,external_next_i18next_.useTranslation)('common');
  const {
    products,
    status,
    shipping_address,
    billing_address,
    tracking_number
  } = order !== null && order !== void 0 ? order : {};
  const {
    price: amount
  } = (0,use_price/* default */.ZP)({
    amount: order === null || order === void 0 ? void 0 : order.amount
  });
  const {
    price: discount
  } = (0,use_price/* default */.ZP)({
    amount: order === null || order === void 0 ? void 0 : order.discount
  });
  const {
    price: total
  } = (0,use_price/* default */.ZP)({
    amount: order === null || order === void 0 ? void 0 : order.total
  });
  const {
    price: delivery_fee
  } = (0,use_price/* default */.ZP)({
    amount: order === null || order === void 0 ? void 0 : order.delivery_fee
  });
  const {
    price: sales_tax
  } = (0,use_price/* default */.ZP)({
    amount: order === null || order === void 0 ? void 0 : order.sales_tax
  });
  return /*#__PURE__*/jsx_runtime_.jsx("div", {
    className: "flex flex-col w-full lg:w-2/3 border border-border-200",
    children: !isEmpty_default()(order) ? /*#__PURE__*/(0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
      children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: "flex flex-col md:flex-row items-center md:justify-between p-5 border-b border-border-200",
        children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("h2", {
          className: "flex font-semibold text-sm md:text-xl text-heading mb-2",
          children: [t('text-order-details'), " ", /*#__PURE__*/jsx_runtime_.jsx("span", {
            className: "px-2",
            children: "-"
          }), ' ', tracking_number]
        }), /*#__PURE__*/(0,jsx_runtime_.jsxs)(ui_link/* default */.Z, {
          href: `${routes/* ROUTES.ORDERS */.Z.ORDERS}/${tracking_number}`,
          className: "font-semibold text-sm text-accent flex items-center transition duration-200 no-underline hover:text-accent-hover focus:text-accent-hover",
          children: [/*#__PURE__*/jsx_runtime_.jsx(eye_icon/* Eye */.b, {
            width: 20,
            className: "me-2"
          }), t('text-sub-orders')]
        })]
      }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: "flex flex-col sm:flex-row border-b border-border-200",
        children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          className: "w-full md:w-3/5 flex flex-col px-5 py-4 border-b sm:border-b-0 sm:border-r border-border-200",
          children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
            className: "mb-4",
            children: [/*#__PURE__*/jsx_runtime_.jsx("span", {
              className: "text-sm text-heading font-bold mb-2 block",
              children: t('text-shipping-address')
            }), /*#__PURE__*/jsx_runtime_.jsx("span", {
              className: "text-sm text-body",
              children: (0,format_address/* formatAddress */.T)(shipping_address)
            })]
          }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
            children: [/*#__PURE__*/jsx_runtime_.jsx("span", {
              className: "text-sm text-heading font-bold mb-2 block",
              children: t('text-billing-address')
            }), /*#__PURE__*/jsx_runtime_.jsx("span", {
              className: "text-sm text-body",
              children: (0,format_address/* formatAddress */.T)(billing_address)
            })]
          })]
        }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          className: "w-full md:w-2/5 flex flex-col px-5 py-4",
          children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
            className: "flex justify-between mb-3",
            children: [/*#__PURE__*/jsx_runtime_.jsx("span", {
              className: "text-sm text-body",
              children: t('text-sub-total')
            }), /*#__PURE__*/jsx_runtime_.jsx("span", {
              className: "text-sm text-heading",
              children: amount
            })]
          }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
            className: "flex justify-between mb-3",
            children: [/*#__PURE__*/jsx_runtime_.jsx("span", {
              className: "text-sm text-body",
              children: t('text-discount')
            }), /*#__PURE__*/jsx_runtime_.jsx("span", {
              className: "text-sm text-heading",
              children: discount
            })]
          }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
            className: "flex justify-between mb-3",
            children: [/*#__PURE__*/jsx_runtime_.jsx("span", {
              className: "text-sm text-body",
              children: t('text-delivery-fee')
            }), /*#__PURE__*/jsx_runtime_.jsx("span", {
              className: "text-sm text-heading",
              children: delivery_fee
            })]
          }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
            className: "flex justify-between mb-3",
            children: [/*#__PURE__*/jsx_runtime_.jsx("span", {
              className: "text-sm text-body",
              children: t('text-tax')
            }), /*#__PURE__*/jsx_runtime_.jsx("span", {
              className: "text-sm text-heading",
              children: sales_tax
            })]
          }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
            className: "flex justify-between",
            children: [/*#__PURE__*/jsx_runtime_.jsx("span", {
              className: "text-sm font-bold text-heading",
              children: t('text-total')
            }), /*#__PURE__*/jsx_runtime_.jsx("span", {
              className: "text-sm font-bold text-heading",
              children: total
            })]
          })]
        })]
      }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
          className: "w-full flex justify-center items-center px-6",
          children: /*#__PURE__*/jsx_runtime_.jsx(orders_status, {
            status: status === null || status === void 0 ? void 0 : status.serial
          })
        }), /*#__PURE__*/jsx_runtime_.jsx(order_items/* OrderItems */.t, {
          products: products
        })]
      })]
    }) : /*#__PURE__*/jsx_runtime_.jsx("div", {
      className: "max-w-lg mx-auto",
      children: /*#__PURE__*/jsx_runtime_.jsx(not_found/* default */.Z, {
        text: "text-no-order-found"
      })
    })
  });
};

/* harmony default export */ const order_details = (OrderDetails);

/***/ }),

/***/ 3315:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5282);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);


const ErrorMessage = ({
  message
}) => {
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
    className: "bg-red-400 p-5 mt-16 mx-auto max-w-sm min-w-min text-center text-lg text-white font-semibold rounded",
    children: message
  });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ErrorMessage);

/***/ }),

/***/ 1859:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(4058);
/* harmony import */ var classnames__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(classnames__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var overlayscrollbars_react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(1958);
/* harmony import */ var overlayscrollbars_react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(overlayscrollbars_react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5282);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__);
const _excluded = ["options", "className", "style"];

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }






const Scrollbar = _ref => {
  let {
    options,
    className,
    style
  } = _ref,
      props = _objectWithoutProperties(_ref, _excluded);

  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_2__.jsx(overlayscrollbars_react__WEBPACK_IMPORTED_MODULE_1__.OverlayScrollbarsComponent, _objectSpread({
    options: _objectSpread({
      className: classnames__WEBPACK_IMPORTED_MODULE_0___default()('os-theme-thin-dark', className),
      scrollbars: {
        autoHide: 'scroll'
      }
    }, options ? options : {}),
    style: style
  }, props));
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Scrollbar);

/***/ }),

/***/ 1919:
/***/ ((module) => {

// Exports
module.exports = {
	"progress_container": "progress-box_progress_container__3V3vU",
	"bar": "progress-box_bar__ReJij",
	"progress_wrapper": "progress-box_progress_wrapper__36diV",
	"checked": "progress-box_checked__ZaAO4",
	"status_wrapper": "progress-box_status_wrapper__30B4b"
};


/***/ })

};
;