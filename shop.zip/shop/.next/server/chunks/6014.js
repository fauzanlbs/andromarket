"use strict";
exports.id = 6014;
exports.ids = [6014];
exports.modules = {

/***/ 6014:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "t": () => (/* binding */ OrderItems)
/* harmony export */ });
/* harmony import */ var _components_ui_table__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5178);
/* harmony import */ var _lib_use_price__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(7259);
/* harmony import */ var next_i18next__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8475);
/* harmony import */ var next_i18next__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_i18next__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _lib_locals__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8972);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9297);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _components_ui_image__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(6126);
/* harmony import */ var _lib_placeholders__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(5980);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(5282);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__);










const OrderItemList = (_, record) => {
  var _record$pivot, _record$pivot2, _record$image$thumbna, _record$image;

  const {
    price
  } = (0,_lib_use_price__WEBPACK_IMPORTED_MODULE_1__/* .default */ .ZP)({
    amount: (_record$pivot = record.pivot) === null || _record$pivot === void 0 ? void 0 : _record$pivot.unit_price
  });
  let name = record.name;

  if (record !== null && record !== void 0 && (_record$pivot2 = record.pivot) !== null && _record$pivot2 !== void 0 && _record$pivot2.variation_option_id) {
    var _record$variation_opt;

    const variationTitle = record === null || record === void 0 ? void 0 : (_record$variation_opt = record.variation_options) === null || _record$variation_opt === void 0 ? void 0 : _record$variation_opt.find(vo => {
      var _record$pivot3;

      return (vo === null || vo === void 0 ? void 0 : vo.id) === (record === null || record === void 0 ? void 0 : (_record$pivot3 = record.pivot) === null || _record$pivot3 === void 0 ? void 0 : _record$pivot3.variation_option_id);
    })["title"];
    name = `${name} - ${variationTitle}`;
  }

  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxs)("div", {
    className: "flex items-center",
    children: [/*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx("div", {
      className: "w-16 h-16 flex flex-shrink-0 rounded overflow-hidden relative",
      children: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(_components_ui_image__WEBPACK_IMPORTED_MODULE_5__/* .Image */ .E, {
        src: (_record$image$thumbna = (_record$image = record.image) === null || _record$image === void 0 ? void 0 : _record$image.thumbnail) !== null && _record$image$thumbna !== void 0 ? _record$image$thumbna : _lib_placeholders__WEBPACK_IMPORTED_MODULE_6__/* .productPlaceholder */ .Hb,
        alt: name,
        className: "w-full h-full object-cover bg-gray-200",
        layout: "fill"
      })
    }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxs)("div", {
      className: "flex flex-col ms-4 overflow-hidden",
      children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxs)("div", {
        className: "flex mb-2 text-body",
        children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsxs)("span", {
          className: "text-[15px] truncate inline-block overflow-hidden",
          children: [name, " x\xA0"]
        }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx("span", {
          className: "text-[15px] text-heading font-semibold truncate inline-block overflow-hidden",
          children: record.unit
        })]
      }), /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx("span", {
        className: "text-[15px] text-accent font-semibold mb-1 truncate inline-block overflow-hidden",
        children: price
      })]
    })]
  });
};

const OrderItems = ({
  products
}) => {
  const {
    t
  } = (0,next_i18next__WEBPACK_IMPORTED_MODULE_2__.useTranslation)("common");
  const {
    alignLeft,
    alignRight
  } = (0,_lib_locals__WEBPACK_IMPORTED_MODULE_3__/* .useIsRTL */ .S)();
  const orderTableColumns = (0,react__WEBPACK_IMPORTED_MODULE_4__.useMemo)(() => [{
    title: /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx("span", {
      className: "ps-20 ms-2",
      children: t("text-product")
    }),
    dataIndex: "",
    key: "items",
    align: alignLeft,
    width: 250,
    ellipsis: true,
    render: OrderItemList
  }, {
    title: t("text-quantity"),
    dataIndex: "pivot",
    key: "pivot",
    align: "center",
    width: 100,
    render: function renderQuantity(pivot) {
      return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx("p", {
        className: "text-[15px] md:text-base font-semibold text-heading",
        children: pivot.order_quantity
      });
    }
  }, {
    title: t("text-price"),
    dataIndex: "pivot",
    key: "price",
    align: "center",
    width: 100,
    render: function RenderPrice(pivot) {
      const {
        price
      } = (0,_lib_use_price__WEBPACK_IMPORTED_MODULE_1__/* .default */ .ZP)({
        amount: pivot.subtotal
      });
      return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx("p", {
        className: "text-[15px] md:text-base font-semibold text-heading",
        children: price
      });
    }
  }], [alignLeft, alignRight, t]);
  return /*#__PURE__*/react_jsx_runtime__WEBPACK_IMPORTED_MODULE_7__.jsx(_components_ui_table__WEBPACK_IMPORTED_MODULE_0__/* .Table */ .i //@ts-ignore
  , {
    columns: orderTableColumns,
    data: products,
    rowKey: record => {
      var _record$pivot4;

      return (_record$pivot4 = record.pivot) !== null && _record$pivot4 !== void 0 && _record$pivot4.variation_option_id ? record.pivot.variation_option_id : record.created_at;
    },
    className: "orderDetailsTable w-full",
    scroll: {
      x: 350,
      y: 500
    }
  });
};

/***/ }),

/***/ 5178:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "i": () => (/* reexport default from dynamic */ rc_table__WEBPACK_IMPORTED_MODULE_0___default.a)
/* harmony export */ });
/* harmony import */ var rc_table__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6356);
/* harmony import */ var rc_table__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(rc_table__WEBPACK_IMPORTED_MODULE_0__);



/***/ }),

/***/ 8972:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "S": () => (/* binding */ useIsRTL)
/* harmony export */ });
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6731);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_0__);

const localeRTLList = ['ar', 'he'];
function useIsRTL() {
  const {
    locale
  } = (0,next_router__WEBPACK_IMPORTED_MODULE_0__.useRouter)();

  if (locale && localeRTLList.includes(locale)) {
    return {
      isRTL: true,
      alignLeft: 'right',
      alignRight: 'left'
    };
  }

  return {
    isRTL: false,
    alignLeft: 'left',
    alignRight: 'right'
  };
}

/***/ })

};
;