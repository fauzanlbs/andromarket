"use strict";
exports.id = 406;
exports.ids = [406];
exports.modules = {

/***/ 406:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ account_layout)
});

// EXTERNAL MODULE: ./src/components/ui/page-header.tsx
var page_header = __webpack_require__(3246);
// EXTERNAL MODULE: ./src/components/ui/container.tsx
var container = __webpack_require__(8835);
// EXTERNAL MODULE: ../node_modules/next/link.js
var next_link = __webpack_require__(9894);
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(6731);
// EXTERNAL MODULE: ../node_modules/react-icons/io5/index.esm.js
var index_esm = __webpack_require__(5936);
// EXTERNAL MODULE: ./src/lib/routes.ts
var routes = __webpack_require__(1103);
// EXTERNAL MODULE: external "next-i18next"
var external_next_i18next_ = __webpack_require__(8475);
// EXTERNAL MODULE: ./src/framework/rest/auth/auth.query.ts + 1 modules
var auth_query = __webpack_require__(6838);
// EXTERNAL MODULE: external "next-auth/client"
var client_ = __webpack_require__(8104);
// EXTERNAL MODULE: external "jotai"
var external_jotai_ = __webpack_require__(8250);
// EXTERNAL MODULE: ./src/store/authorization-atom.ts
var authorization_atom = __webpack_require__(8879);
// EXTERNAL MODULE: external "js-cookie"
var external_js_cookie_ = __webpack_require__(6155);
var external_js_cookie_default = /*#__PURE__*/__webpack_require__.n(external_js_cookie_);
// EXTERNAL MODULE: ./src/lib/constants.ts
var constants = __webpack_require__(509);
// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(5282);
;// CONCATENATED MODULE: ./src/components/my-account/account-nav.tsx
const _excluded = ["pathname"];

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }














const accountMenu = [{
  slug: routes/* ROUTES.ACCOUNT */.Z.ACCOUNT,
  name: "text-dashboard",
  icon: /*#__PURE__*/jsx_runtime_.jsx(index_esm/* IoHomeOutline */.yl6, {
    className: "w-5 h-5"
  })
}, {
  slug: routes/* ROUTES.ACCOUNT_ORDERS */.Z.ACCOUNT_ORDERS,
  name: "text-orders",
  icon: /*#__PURE__*/jsx_runtime_.jsx(index_esm/* IoCartOutline */.toq, {
    className: "w-5 h-5"
  })
}, {
  slug: routes/* ROUTES.ACCOUNT_ADDRESS */.Z.ACCOUNT_ADDRESS,
  name: "text-account-address",
  icon: /*#__PURE__*/jsx_runtime_.jsx(index_esm/* IoPersonOutline */.FJ3, {
    className: "w-5 h-5"
  })
}, {
  slug: routes/* ROUTES.ACCOUNT_CONTACT_NUMBER */.Z.ACCOUNT_CONTACT_NUMBER,
  name: "text-contact-number",
  icon: /*#__PURE__*/jsx_runtime_.jsx(index_esm/* IoPersonOutline */.FJ3, {
    className: "w-5 h-5"
  })
}, {
  slug: routes/* ROUTES.ACCOUNT_CHANGE_PASSWORD */.Z.ACCOUNT_CHANGE_PASSWORD,
  name: "text-change-password",
  icon: /*#__PURE__*/jsx_runtime_.jsx(index_esm/* IoSettingsOutline */.Fuo, {
    className: "w-5 h-5"
  })
}];
function AccountNav() {
  const {
    mutate
  } = (0,auth_query/* useLogoutMutation */._y)();

  const _useRouter = (0,router_.useRouter)(),
        {
    pathname
  } = _useRouter,
        router = _objectWithoutProperties(_useRouter, _excluded);

  const newPathname = pathname.split("/").slice(2, 3);
  const [, authorize] = (0,external_jotai_.useAtom)(authorization_atom/* authorizationAtom */.O);
  const mainPath = `/${newPathname[0]}`;
  const {
    t
  } = (0,external_next_i18next_.useTranslation)("common");

  async function onClickLogout() {
    await (0,client_.signOut)({
      redirect: false
    });
    mutate(undefined, {
      onSuccess: () => {
        external_js_cookie_default().remove(constants/* AUTH_TOKEN */.UA);
        authorize(false);
        router.push("/");
      }
    });
  }

  return /*#__PURE__*/(0,jsx_runtime_.jsxs)("nav", {
    className: "flex flex-col md:w-2/6 2xl:w-4/12 md:pe-8 lg:pe-12 xl:pe-16 2xl:pe-20 pb-2 md:pb-0",
    children: [accountMenu.map(item => {
      const menuPathname = item.slug.split("/").slice(2, 3);
      const menuPath = `/${menuPathname[0]}`;
      return /*#__PURE__*/jsx_runtime_.jsx(next_link.default, {
        href: item.slug,
        children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("a", {
          className: mainPath === menuPath ? "bg-gray-100 font-semibold flex items-center cursor-pointer text-sm lg:text-base text-heading py-3.5 px-4 lg:px-5 rounded mb-2 " : "flex items-center cursor-pointer text-sm lg:text-base text-heading font-normal py-3.5 px-4 lg:px-5 rounded mb-2",
          children: [item.icon, /*#__PURE__*/jsx_runtime_.jsx("span", {
            className: "ps-2",
            children: t(`${item.name}`)
          })]
        })
      }, item.slug);
    }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("button", {
      className: "flex items-center cursor-pointer text-sm lg:text-base text-heading font-normal py-3.5 px-4 lg:px-5 focus:outline-none",
      onClick: onClickLogout,
      children: [/*#__PURE__*/jsx_runtime_.jsx(index_esm/* IoLogOutOutline */.qgu, {
        className: "w-5 h-5"
      }), /*#__PURE__*/jsx_runtime_.jsx("span", {
        className: "ps-2",
        children: t("text-logout")
      })]
    })]
  });
}
// EXTERNAL MODULE: ./src/components/common/subscription.tsx
var subscription = __webpack_require__(3923);
;// CONCATENATED MODULE: ./src/components/my-account/account-layout.tsx








const AccountLayout = ({
  children
}) => {
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
    children: [/*#__PURE__*/jsx_runtime_.jsx(page_header/* default */.Z, {
      pageHeader: "text-page-my-account"
    }), /*#__PURE__*/(0,jsx_runtime_.jsxs)(container/* default */.Z, {
      children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
        className: "py-16 lg:py-20 px-0 xl:max-w-screen-xl mx-auto flex  md:flex-row w-full",
        children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          className: "flex flex-col md:flex-row w-full",
          children: [/*#__PURE__*/jsx_runtime_.jsx(AccountNav, {}), /*#__PURE__*/jsx_runtime_.jsx("div", {
            className: "md:w-4/6 2xl:w-8/12 mt-4 md:mt-0",
            children: children
          })]
        })
      }), /*#__PURE__*/jsx_runtime_.jsx(subscription/* default */.Z, {})]
    })]
  });
};

/* harmony default export */ const account_layout = (AccountLayout);

/***/ })

};
;