"use strict";
(() => {
var exports = {};
exports.id = 6660;
exports.ids = [6660];
exports.modules = {

/***/ 3325:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ OrdersPage),
  "getStaticProps": () => (/* reexport */ common/* getStaticProps */.b)
});

;// CONCATENATED MODULE: external "rc-collapse"
const external_rc_collapse_namespaceObject = require("rc-collapse");
var external_rc_collapse_default = /*#__PURE__*/__webpack_require__.n(external_rc_collapse_namespaceObject);
// EXTERNAL MODULE: ./src/components/ui/error-message.tsx
var error_message = __webpack_require__(3315);
// EXTERNAL MODULE: ./src/components/ui/button.tsx
var ui_button = __webpack_require__(7993);
// EXTERNAL MODULE: ./src/components/404/not-found.tsx
var not_found = __webpack_require__(2973);
// EXTERNAL MODULE: ./src/components/ui/scrollbar.tsx
var scrollbar = __webpack_require__(1859);
// EXTERNAL MODULE: external "next-i18next"
var external_next_i18next_ = __webpack_require__(8475);
// EXTERNAL MODULE: ./src/components/orders/order-details.tsx + 3 modules
var order_details = __webpack_require__(2444);
// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(5282);
;// CONCATENATED MODULE: ./src/components/orders/orders-with-loader.tsx
 // import Spinner from '@components/ui/loaders/spinner/spinner';








const OrdersWithLoader = ({
  showLoaders,
  hasNextPage,
  isLoadingMore,
  onLoadMore,
  notFound,
  children,
  order
}) => {
  const {
    t
  } = (0,external_next_i18next_.useTranslation)('common');
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
    className: "w-full hidden overflow-hidden lg:flex",
    children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
      className: "pe-5 lg:pe-8 w-full md:w-1/3",
      style: {
        height: 'calc(100vh - 60px)'
      },
      children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: "flex flex-col h-full pb-5 md:border md:border-border-200",
        children: [/*#__PURE__*/jsx_runtime_.jsx("h3", {
          className: "text-xl font-semibold py-5 text-heading px-5",
          children: t('profile-sidebar-orders')
        }), /*#__PURE__*/(0,jsx_runtime_.jsxs)(scrollbar/* default */.Z, {
          className: "w-full",
          style: {
            height: 'calc(100% - 80px)'
          },
          children: [showLoaders ? /*#__PURE__*/jsx_runtime_.jsx("p", {}) : /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
            className: "px-5",
            children: [children, hasNextPage && /*#__PURE__*/jsx_runtime_.jsx("div", {
              className: "flex justify-center mt-8 lg:mt-12",
              children: /*#__PURE__*/jsx_runtime_.jsx(ui_button/* default */.Z, {
                loading: isLoadingMore,
                onClick: onLoadMore,
                className: "text-sm md:text-base font-semibold h-11",
                children: t('text-load-more')
              })
            })]
          }), notFound && /*#__PURE__*/jsx_runtime_.jsx("div", {
            className: "w-full h-full flex items-center justify-center my-auto",
            children: /*#__PURE__*/jsx_runtime_.jsx("h4", {
              className: "text-sm font-semibold text-body text-center",
              children: t('error-no-orders')
            })
          })]
        })]
      })
    }), Boolean(order) ? /*#__PURE__*/jsx_runtime_.jsx(order_details/* default */.Z, {
      order: order
    }) : /*#__PURE__*/jsx_runtime_.jsx("div", {
      className: "max-w-lg mx-auto",
      children: /*#__PURE__*/jsx_runtime_.jsx(not_found/* default */.Z, {
        text: "text-no-order-found"
      })
    })]
  });
};

/* harmony default export */ const orders_with_loader = (OrdersWithLoader);
// EXTERNAL MODULE: ./src/framework/rest/orders/orders.query.ts
var orders_query = __webpack_require__(2702);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(9297);
var external_react_default = /*#__PURE__*/__webpack_require__.n(external_react_);
// EXTERNAL MODULE: ./src/lib/use-price.ts
var use_price = __webpack_require__(7259);
// EXTERNAL MODULE: external "dayjs"
var external_dayjs_ = __webpack_require__(8349);
var external_dayjs_default = /*#__PURE__*/__webpack_require__.n(external_dayjs_);
// EXTERNAL MODULE: external "classnames"
var external_classnames_ = __webpack_require__(4058);
var external_classnames_default = /*#__PURE__*/__webpack_require__.n(external_classnames_);
;// CONCATENATED MODULE: ./src/components/orders/order-card.tsx







const OrderCard = ({
  onClick,
  order,
  isActive
}) => {
  const {
    t
  } = (0,external_next_i18next_.useTranslation)('common');
  const {
    id,
    status,
    created_at,
    delivery_time
  } = order;
  const {
    price: amount
  } = (0,use_price/* default */.ZP)({
    amount: order === null || order === void 0 ? void 0 : order.amount
  });
  const {
    price: total
  } = (0,use_price/* default */.ZP)({
    amount: order === null || order === void 0 ? void 0 : order.total
  });
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
    onClick: onClick,
    role: "button",
    className: external_classnames_default()('bg-gray-100 rounded overflow-hidden w-full flex flex-shrink-0 flex-col mb-4 border-2 border-transparent cursor-pointer last:mb-0', isActive === true && '!border-accent'),
    children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      className: "flex justify-between items-center border-b border-border-200 py-3 px-5 md:px-3 lg:px-5 ",
      children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("span", {
        className: "flex font-bold text-sm lg:text-base text-heading me-4 flex-shrink-0",
        children: [t('text-order'), /*#__PURE__*/(0,jsx_runtime_.jsxs)("span", {
          className: "font-normal",
          children: ["#", id]
        })]
      }), /*#__PURE__*/jsx_runtime_.jsx("span", {
        className: "text-sm text-blue-500 bg-blue-100 px-3 py-2 rounded whitespace-nowrap truncate max-w-full",
        title: status.name,
        children: status.name
      })]
    }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      className: "flex flex-col p-5 md:p-3 lg:px-4 lg:py-5",
      children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("p", {
        className: "text-sm text-heading w-full flex justify-between items-center mb-4 last:mb-0",
        children: [/*#__PURE__*/jsx_runtime_.jsx("span", {
          className: "w-24 overflow-hidden flex-shrink-0",
          children: t('text-order-date')
        }), /*#__PURE__*/jsx_runtime_.jsx("span", {
          className: "me-auto",
          children: ":"
        }), /*#__PURE__*/jsx_runtime_.jsx("span", {
          className: "ms-1",
          children: external_dayjs_default()(created_at).format('MMMM D, YYYY')
        })]
      }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("p", {
        className: "text-sm text-heading w-full flex justify-between items-center mb-4 last:mb-0",
        children: [/*#__PURE__*/jsx_runtime_.jsx("span", {
          className: "w-24 overflow-hidden flex-shrink-0",
          children: t('text-deliver-time')
        }), /*#__PURE__*/jsx_runtime_.jsx("span", {
          className: "me-auto",
          children: ":"
        }), /*#__PURE__*/jsx_runtime_.jsx("span", {
          className: "ms-1 truncate",
          children: delivery_time
        })]
      }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("p", {
        className: "text-sm font-bold text-heading w-full flex justify-between items-center mb-4 last:mb-0",
        children: [/*#__PURE__*/jsx_runtime_.jsx("span", {
          className: "w-24 overflow-hidden flex-shrink-0",
          children: t('text-amount')
        }), /*#__PURE__*/jsx_runtime_.jsx("span", {
          className: "me-auto",
          children: ":"
        }), /*#__PURE__*/jsx_runtime_.jsx("span", {
          className: "ms-1",
          children: amount
        })]
      }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("p", {
        className: "text-sm font-bold text-heading w-full flex justify-between items-center mb-4 last:mb-0",
        children: [/*#__PURE__*/jsx_runtime_.jsx("span", {
          className: "w-24 overflow-hidden flex-shrink-0",
          children: t('text-total-price')
        }), /*#__PURE__*/jsx_runtime_.jsx("span", {
          className: "me-auto",
          children: ":"
        }), /*#__PURE__*/jsx_runtime_.jsx("span", {
          className: "ms-1",
          children: total
        })]
      })]
    })]
  });
};

/* harmony default export */ const order_card = (OrderCard);
// EXTERNAL MODULE: ./src/components/ui/image.tsx
var ui_image = __webpack_require__(6126);
// EXTERNAL MODULE: ./src/assets/no-result.svg
var no_result = __webpack_require__(8465);
;// CONCATENATED MODULE: ./src/components/orders/order-list-mobile.tsx









const OrderListMobile = ({
  showLoaders,
  hasNextPage,
  isLoadingMore,
  onLoadMore,
  notFound,
  children,
  order
}) => {
  const {
    t
  } = (0,external_next_i18next_.useTranslation)('common');
  return /*#__PURE__*/jsx_runtime_.jsx("div", {
    className: "flex flex-col w-full lg:hidden",
    children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      className: "flex flex-col w-full h-full px-0 pb-5",
      children: [/*#__PURE__*/jsx_runtime_.jsx("h3", {
        className: "text-xl font-semibold pb-5 text-heading",
        children: t('profile-sidebar-orders')
      }), Boolean(order) && /*#__PURE__*/(0,jsx_runtime_.jsxs)((external_rc_collapse_default()), {
        accordion: true,
        defaultActiveKey: "active",
        expandIcon: () => null,
        children: [showLoaders ? /*#__PURE__*/jsx_runtime_.jsx("p", {
          children: /*#__PURE__*/jsx_runtime_.jsx("h2", {
            children: "Loading..."
          })
        }) : children, hasNextPage && /*#__PURE__*/jsx_runtime_.jsx("div", {
          className: "flex justify-center mt-8",
          children: /*#__PURE__*/jsx_runtime_.jsx(ui_button/* default */.Z, {
            loading: isLoadingMore,
            onClick: onLoadMore,
            className: "text-sm md:text-base font-semibold h-11",
            children: t('text-load-more')
          })
        })]
      }), notFound && /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: "w-full h-full flex flex-col items-center justify-center py-10 my-auto",
        children: [/*#__PURE__*/jsx_runtime_.jsx("div", {
          className: "w-5/6 h-full flex items-center justify-center mb-7",
          children: /*#__PURE__*/jsx_runtime_.jsx(ui_image/* Image */.E, {
            src: no_result/* default */.Z,
            className: "w-full h-full object-contain",
            alt: "No Order Found"
          })
        }), /*#__PURE__*/jsx_runtime_.jsx("h4", {
          className: "text-sm font-semibold text-body text-center",
          children: t('error-no-orders')
        })]
      })]
    })
  });
};

/* harmony default export */ const order_list_mobile = (OrderListMobile);
;// CONCATENATED MODULE: ./src/framework/rest/orders/orders.tsx










function Orders() {
  var _data$pages2, _data$pages2$, _data$pages2$$data, _data$pages3, _data$pages4, _data$pages5, _data$pages5$, _data$pages5$$data, _data$pages6, _data$pages7;

  const {
    data,
    isFetching: loading,
    error,
    fetchNextPage,
    hasNextPage,
    isFetchingNextPage: loadingMore
  } = (0,orders_query/* useOrdersQuery */.mU)({});
  const {
    0: order,
    1: setOrder
  } = (0,external_react_.useState)({});
  (0,external_react_.useEffect)(() => {
    var _data$pages;

    if (data !== null && data !== void 0 && (_data$pages = data.pages) !== null && _data$pages !== void 0 && _data$pages[0].data.length) {
      setOrder(data.pages[0].data[0]);
    }
  }, [data === null || data === void 0 ? void 0 : data.pages, data === null || data === void 0 ? void 0 : data.pages.length]);
  if (error) return /*#__PURE__*/jsx_runtime_.jsx(error_message/* default */.Z, {
    message: error.message
  });

  function handleLoadMore() {
    fetchNextPage();
  }

  return /*#__PURE__*/(0,jsx_runtime_.jsxs)((external_react_default()).Fragment, {
    children: [/*#__PURE__*/jsx_runtime_.jsx(orders_with_loader, {
      notFound: !loading && !(data !== null && data !== void 0 && (_data$pages2 = data.pages) !== null && _data$pages2 !== void 0 && (_data$pages2$ = _data$pages2[0]) !== null && _data$pages2$ !== void 0 && (_data$pages2$$data = _data$pages2$.data) !== null && _data$pages2$$data !== void 0 && _data$pages2$$data.length),
      isLoadingMore: loadingMore,
      onLoadMore: handleLoadMore,
      showLoaders: loading && !(data !== null && data !== void 0 && (_data$pages3 = data.pages) !== null && _data$pages3 !== void 0 && _data$pages3.length),
      hasNextPage: Boolean(hasNextPage),
      order: order,
      children: data === null || data === void 0 ? void 0 : (_data$pages4 = data.pages) === null || _data$pages4 === void 0 ? void 0 : _data$pages4.map((page, idx) => {
        var _page$data;

        return /*#__PURE__*/jsx_runtime_.jsx(external_react_.Fragment, {
          children: page === null || page === void 0 ? void 0 : (_page$data = page.data) === null || _page$data === void 0 ? void 0 : _page$data.map((_order, index) => /*#__PURE__*/jsx_runtime_.jsx(order_card, {
            order: _order,
            onClick: () => setOrder(_order),
            isActive: (order === null || order === void 0 ? void 0 : order.id) === (_order === null || _order === void 0 ? void 0 : _order.id)
          }, index))
        }, idx);
      })
    }), /*#__PURE__*/jsx_runtime_.jsx(order_list_mobile, {
      notFound: !loading && !(data !== null && data !== void 0 && (_data$pages5 = data.pages) !== null && _data$pages5 !== void 0 && (_data$pages5$ = _data$pages5[0]) !== null && _data$pages5$ !== void 0 && (_data$pages5$$data = _data$pages5$.data) !== null && _data$pages5$$data !== void 0 && _data$pages5$$data.length),
      isLoadingMore: loadingMore,
      onLoadMore: handleLoadMore,
      showLoaders: loading && !(data !== null && data !== void 0 && (_data$pages6 = data.pages) !== null && _data$pages6 !== void 0 && _data$pages6.length),
      hasNextPage: Boolean(hasNextPage),
      order: order,
      children: data === null || data === void 0 ? void 0 : (_data$pages7 = data.pages) === null || _data$pages7 === void 0 ? void 0 : _data$pages7.map((page, idx) => {
        var _page$data2;

        return /*#__PURE__*/jsx_runtime_.jsx(external_react_.Fragment, {
          children: page === null || page === void 0 ? void 0 : (_page$data2 = page.data) === null || _page$data2 === void 0 ? void 0 : _page$data2.map((_order, index) => /*#__PURE__*/jsx_runtime_.jsx((external_rc_collapse_default()).Panel, {
            header: /*#__PURE__*/jsx_runtime_.jsx(order_card, {
              order: _order,
              onClick: () => setOrder(_order),
              isActive: (order === null || order === void 0 ? void 0 : order.id) === (_order === null || _order === void 0 ? void 0 : _order.id)
            }, `mobile_${index}`),
            headerClass: "accordion-title",
            className: "mb-4",
            children: /*#__PURE__*/jsx_runtime_.jsx(order_details/* default */.Z, {
              order: order
            })
          }, index))
        }, idx);
      })
    })]
  });
}
// EXTERNAL MODULE: ./src/components/layout/layout.tsx + 21 modules
var layout = __webpack_require__(4596);
// EXTERNAL MODULE: ./src/framework/rest/ssr/common.ts
var common = __webpack_require__(857);
;// CONCATENATED MODULE: ./src/pages/orders/index.tsx




function OrdersPage() {
  return /*#__PURE__*/jsx_runtime_.jsx(Orders, {});
}
OrdersPage.authenticate = true;
OrdersPage.getLayout = layout/* getLayout */.G;

/***/ }),

/***/ 2376:
/***/ ((module) => {

module.exports = require("axios");

/***/ }),

/***/ 8023:
/***/ ((module) => {

module.exports = require("body-scroll-lock");

/***/ }),

/***/ 3687:
/***/ ((module) => {

module.exports = require("camelcase-keys");

/***/ }),

/***/ 4058:
/***/ ((module) => {

module.exports = require("classnames");

/***/ }),

/***/ 8349:
/***/ ((module) => {

module.exports = require("dayjs");

/***/ }),

/***/ 8250:
/***/ ((module) => {

module.exports = require("jotai");

/***/ }),

/***/ 3837:
/***/ ((module) => {

module.exports = require("jotai/utils");

/***/ }),

/***/ 6155:
/***/ ((module) => {

module.exports = require("js-cookie");

/***/ }),

/***/ 3089:
/***/ ((module) => {

module.exports = require("lodash/groupBy");

/***/ }),

/***/ 8718:
/***/ ((module) => {

module.exports = require("lodash/isEmpty");

/***/ }),

/***/ 4661:
/***/ ((module) => {

module.exports = require("lodash/pickBy");

/***/ }),

/***/ 8475:
/***/ ((module) => {

module.exports = require("next-i18next");

/***/ }),

/***/ 3295:
/***/ ((module) => {

module.exports = require("next-i18next/serverSideTranslations");

/***/ }),

/***/ 9325:
/***/ ((module) => {

module.exports = require("next/dist/server/denormalize-page-path.js");

/***/ }),

/***/ 822:
/***/ ((module) => {

module.exports = require("next/dist/server/image-config.js");

/***/ }),

/***/ 6695:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 8300:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/detect-domain-locale.js");

/***/ }),

/***/ 5378:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 2307:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/loadable.js");

/***/ }),

/***/ 7162:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 8773:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 2248:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 9372:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 665:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 2747:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 333:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 3456:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 556:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/to-base-64.js");

/***/ }),

/***/ 7620:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 6731:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 1958:
/***/ ((module) => {

module.exports = require("overlayscrollbars-react");

/***/ }),

/***/ 1346:
/***/ ((module) => {

module.exports = require("rc-drawer");

/***/ }),

/***/ 6356:
/***/ ((module) => {

module.exports = require("rc-table");

/***/ }),

/***/ 9297:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 9081:
/***/ ((module) => {

module.exports = require("react-content-loader");

/***/ }),

/***/ 2585:
/***/ ((module) => {

module.exports = require("react-query");

/***/ }),

/***/ 9475:
/***/ ((module) => {

module.exports = require("react-query/hydration");

/***/ }),

/***/ 173:
/***/ ((module) => {

module.exports = require("react-use/lib/useLocalStorage");

/***/ }),

/***/ 5282:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [8688,7228,5396,8147,4596,7993,2405,857,9204,6098,1097,2973,5980,2702,6014,2444], () => (__webpack_exec__(3325)));
module.exports = __webpack_exports__;

})();