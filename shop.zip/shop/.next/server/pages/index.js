"use strict";
(() => {
var exports = {};
exports.id = 5405;
exports.ids = [5405];
exports.modules = {

/***/ 3015:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ Home),
  "getStaticProps": () => (/* reexport */ pages/* getStaticProps */.b)
});

// EXTERNAL MODULE: ./src/components/common/banner-card.tsx
var banner_card = __webpack_require__(5038);
// EXTERNAL MODULE: ./src/components/ui/container.tsx
var container = __webpack_require__(8835);
// EXTERNAL MODULE: ./src/containers/collection-block.tsx + 1 modules
var collection_block = __webpack_require__(2992);
// EXTERNAL MODULE: ./src/components/ui/carousel/carousel.tsx
var carousel = __webpack_require__(4365);
// EXTERNAL MODULE: external "swiper/react"
var react_ = __webpack_require__(2156);
// EXTERNAL MODULE: ./src/lib/routes.ts
var routes = __webpack_require__(1103);
// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(5282);
;// CONCATENATED MODULE: ./src/containers/banner-carousel-block.tsx





const breakpoints = {
  "1025": {
    slidesPerView: 3,
    spaceBetween: 28
  },
  "480": {
    slidesPerView: 2,
    spaceBetween: 20
  },
  "0": {
    slidesPerView: 1,
    spaceBetween: 12
  }
};

const BannerCarouselBlock = ({
  className = "mb-12 md:mb-12 lg:mb-14 pb-0.5 xl:pb-1.5",
  banners
}) => {
  return /*#__PURE__*/jsx_runtime_.jsx("div", {
    className: className,
    children: /*#__PURE__*/jsx_runtime_.jsx(carousel/* default */.Z, {
      breakpoints: breakpoints,
      autoplay: {
        delay: 5000
      },
      children: banners === null || banners === void 0 ? void 0 : banners.map(banner => /*#__PURE__*/jsx_runtime_.jsx(react_.SwiperSlide, {
        children: /*#__PURE__*/jsx_runtime_.jsx(banner_card/* default */.Z, {
          banner: banner,
          href: `${routes/* ROUTES.COLLECTIONS */.Z.COLLECTIONS}/${banner.slug}`,
          effectActive: true
        })
      }, `promotion-banner-key-${banner === null || banner === void 0 ? void 0 : banner.id}`))
    })
  });
};

/* harmony default export */ const banner_carousel_block = (BannerCarouselBlock);
// EXTERNAL MODULE: ./src/components/ui/divider.tsx
var divider = __webpack_require__(5313);
// EXTERNAL MODULE: ./src/components/common/download-apps.tsx
var download_apps = __webpack_require__(7195);
// EXTERNAL MODULE: ./src/components/common/support.tsx
var support = __webpack_require__(7063);
// EXTERNAL MODULE: ./src/components/common/subscription.tsx
var subscription = __webpack_require__(3923);
// EXTERNAL MODULE: ./src/utils/use-window-size.ts
var use_window_size = __webpack_require__(3396);
;// CONCATENATED MODULE: ./src/containers/hero-block.tsx






const hero_block_breakpoints = {
  "1500": {
    slidesPerView: 2
  },
  "0": {
    slidesPerView: 1
  }
};

const HeroBlock = ({
  banners
}) => {
  const {
    width
  } = (0,use_window_size/* useWindowSize */.i)();
  return /*#__PURE__*/jsx_runtime_.jsx("div", {
    className: "heroBannerOne relative max-w-[1920px] mb-5 md:mb-12 lg:mb-14 2xl:mb-16 mx-auto overflow-hidden px-4 md:px-8 2xl:px-0",
    children: /*#__PURE__*/jsx_runtime_.jsx(carousel/* default */.Z, {
      breakpoints: hero_block_breakpoints,
      centeredSlides: width < 1500 ? false : true,
      autoplay: {
        delay: 5000
      },
      className: "mx-0",
      buttonClassName: "hidden",
      pagination: {
        clickable: true
      },
      children: banners === null || banners === void 0 ? void 0 : banners.map(banner => /*#__PURE__*/jsx_runtime_.jsx(react_.SwiperSlide, {
        className: "carouselItem px-0 2xl:px-3.5",
        children: /*#__PURE__*/jsx_runtime_.jsx(banner_card/* default */.Z, {
          banner: banner,
          href: `${routes/* ROUTES.COLLECTIONS */.Z.COLLECTIONS}/${banner.slug}`
        })
      }, `banner--key-${banner === null || banner === void 0 ? void 0 : banner.id}`))
    })
  });
};

/* harmony default export */ const hero_block = (HeroBlock);
// EXTERNAL MODULE: ./src/containers/brand-block.tsx
var brand_block = __webpack_require__(5748);
// EXTERNAL MODULE: ./src/containers/category-block.tsx + 1 modules
var category_block = __webpack_require__(5767);
// EXTERNAL MODULE: ./src/containers/feature-block.tsx + 1 modules
var feature_block = __webpack_require__(8852);
// EXTERNAL MODULE: ./src/components/layout/layout.tsx + 21 modules
var layout = __webpack_require__(4596);
// EXTERNAL MODULE: ./src/components/common/sale-with-progress.tsx + 3 modules
var sale_with_progress = __webpack_require__(2577);
// EXTERNAL MODULE: ./src/framework/rest/products/products.query.ts
var products_query = __webpack_require__(2317);
// EXTERNAL MODULE: external "classnames"
var external_classnames_ = __webpack_require__(4058);
var external_classnames_default = /*#__PURE__*/__webpack_require__.n(external_classnames_);
// EXTERNAL MODULE: ./src/components/ui/alert.tsx
var ui_alert = __webpack_require__(5013);
// EXTERNAL MODULE: external "next-i18next"
var external_next_i18next_ = __webpack_require__(8475);
// EXTERNAL MODULE: external "lodash/isEmpty"
var isEmpty_ = __webpack_require__(8718);
var isEmpty_default = /*#__PURE__*/__webpack_require__.n(isEmpty_);
// EXTERNAL MODULE: ./src/components/404/not-found-item.tsx
var not_found_item = __webpack_require__(6857);
// EXTERNAL MODULE: ./src/settings/site.settings.tsx + 6 modules
var site_settings = __webpack_require__(5278);
;// CONCATENATED MODULE: ./src/components/product/feeds/flash-sale-product-feed.tsx












const banner = {
  id: 1,
  title: "banner-on-selected-items",
  slug: "search",
  image: {
    mobile: {
      url: "/assets/images/banner/banner-mobile-2.jpg",
      width: 450,
      height: 150
    },
    desktop: {
      url: "/assets/images/banner/banner-2.jpg",
      width: 1190,
      height: 450
    }
  }
};
const flashSaleCarouselBreakpoint = {
  "1280": {
    slidesPerView: 1
  },
  "1025": {
    slidesPerView: 2,
    spaceBetween: 28
  },
  "768": {
    slidesPerView: 2,
    spaceBetween: 20
  },
  "0": {
    slidesPerView: 1
  }
};

const FlashSaleBlock = ({
  className = "mb-12 lg:mb-14 xl:mb-7"
}) => {
  var _flashSellSettings$li, _flashSellSettings$sl, _products$pages, _products$pages$;

  const {
    t
  } = (0,external_next_i18next_.useTranslation)();
  const flashSellSettings = site_settings/* siteSettings.homePageBlocks.flashSale */.U.homePageBlocks.flashSale;
  const {
    data: products,
    isLoading: loading,
    error
  } = (0,products_query/* useProductsQuery */.kN)({
    limit: (_flashSellSettings$li = flashSellSettings.limit) !== null && _flashSellSettings$li !== void 0 ? _flashSellSettings$li : 10,
    tags: (_flashSellSettings$sl = flashSellSettings.slug) !== null && _flashSellSettings$sl !== void 0 ? _flashSellSettings$sl : "flash-sale"
  });

  if (!loading && isEmpty_default()(products === null || products === void 0 ? void 0 : (_products$pages = products.pages) === null || _products$pages === void 0 ? void 0 : _products$pages[0].data)) {
    return /*#__PURE__*/jsx_runtime_.jsx(not_found_item/* default */.Z, {
      text: t("text-no-flash-products-found")
    });
  }

  return /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
    className: external_classnames_default()(`grid grid-cols-1 xl:grid-cols-3 gap-y-12 lg:gap-y-14 xl:gap-y-0 xl:gap-x-7`, className),
    children: [/*#__PURE__*/jsx_runtime_.jsx(banner_card/* default */.Z, {
      banner: banner,
      href: `${routes/* ROUTES.COLLECTIONS */.Z.COLLECTIONS}/${banner.slug}`,
      className: "xl:h-full xl:col-span-2",
      effectActive: true
    }, `banner--key${banner.id}`), error ? /*#__PURE__*/jsx_runtime_.jsx(ui_alert/* default */.Z, {
      message: error === null || error === void 0 ? void 0 : error.message
    }) : /*#__PURE__*/jsx_runtime_.jsx(sale_with_progress/* default */.Z, {
      carouselBreakpoint: flashSaleCarouselBreakpoint,
      products: products === null || products === void 0 ? void 0 : (_products$pages$ = products.pages[0]) === null || _products$pages$ === void 0 ? void 0 : _products$pages$.data,
      loading: loading,
      className: "col-span-full xl:col-span-1 lg:mb-1 xl:mb-0"
    })]
  });
};

/* harmony default export */ const flash_sale_product_feed = (FlashSaleBlock);
// EXTERNAL MODULE: ./src/components/product/feeds/best-seller-product-feed.tsx
var best_seller_product_feed = __webpack_require__(2563);
// EXTERNAL MODULE: ./src/components/product/feeds/new-arrivals-product-feed.tsx
var new_arrivals_product_feed = __webpack_require__(4584);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(9297);
// EXTERNAL MODULE: ./src/contexts/ui.context.tsx
var ui_context = __webpack_require__(4580);
// EXTERNAL MODULE: ./src/framework/rest/banner/banner.query.ts
var banner_query = __webpack_require__(9658);
// EXTERNAL MODULE: ./src/framework/rest/ssr/pages.ts
var pages = __webpack_require__(9218);
;// CONCATENATED MODULE: ./src/pages/index.tsx
























function Home() {
  var _banners$homeOneBanne;

  const {
    data: banners
  } = (0,banner_query/* useBannerQuery */.E)();
  const {
    openModal,
    setModalView
  } = (0,ui_context/* useUI */.l8)();
  (0,external_react_.useEffect)(() => {
    setModalView("NEWSLETTER_VIEW");
    setTimeout(() => {
      openModal();
    }, 2000);
  }, []);
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
    children: [/*#__PURE__*/jsx_runtime_.jsx(hero_block, {
      banners: banners === null || banners === void 0 ? void 0 : banners.homeOneHeroBanner
    }), /*#__PURE__*/(0,jsx_runtime_.jsxs)(container/* default */.Z, {
      children: [/*#__PURE__*/jsx_runtime_.jsx(flash_sale_product_feed, {}), /*#__PURE__*/jsx_runtime_.jsx(banner_carousel_block, {
        banners: banners === null || banners === void 0 ? void 0 : banners.promotionBannerTwo
      }), /*#__PURE__*/jsx_runtime_.jsx(category_block/* default */.Z, {
        sectionHeading: "text-shop-by-category"
      }), /*#__PURE__*/jsx_runtime_.jsx(divider/* default */.Z, {}), /*#__PURE__*/jsx_runtime_.jsx(best_seller_product_feed/* default */.Z, {}), /*#__PURE__*/jsx_runtime_.jsx(banner_card/* default */.Z, {
        banner: banners === null || banners === void 0 ? void 0 : banners.homeOneBanner,
        href: `${routes/* ROUTES.COLLECTIONS */.Z.COLLECTIONS}/${banners === null || banners === void 0 ? void 0 : (_banners$homeOneBanne = banners.homeOneBanner) === null || _banners$homeOneBanne === void 0 ? void 0 : _banners$homeOneBanne.slug}`,
        className: "mb-12 lg:mb-14 xl:mb-16 pb-0.5 lg:pb-1 xl:pb-0",
        classNameInner: "h-28 sm:h-auto"
      }, `banner--key${banners === null || banners === void 0 ? void 0 : banners.homeOneBanner.id}`), /*#__PURE__*/jsx_runtime_.jsx(new_arrivals_product_feed/* default */.Z, {}), /*#__PURE__*/jsx_runtime_.jsx(divider/* default */.Z, {}), /*#__PURE__*/jsx_runtime_.jsx(brand_block/* default */.Z, {
        sectionHeading: "text-top-brands"
      }), /*#__PURE__*/jsx_runtime_.jsx(collection_block/* default */.Z, {}), /*#__PURE__*/jsx_runtime_.jsx(feature_block/* default */.Z, {}), /*#__PURE__*/jsx_runtime_.jsx(download_apps/* default */.Z, {
        className: "bg-linen"
      }), /*#__PURE__*/jsx_runtime_.jsx(support/* default */.Z, {}), /*#__PURE__*/jsx_runtime_.jsx(subscription/* default */.Z, {
        className: "bg-linen px-5 sm:px-8 md:px-16 2xl:px-24"
      })]
    })]
  });
}
Home.getLayout = layout/* getLayout */.G;

/***/ }),

/***/ 2166:
/***/ ((module) => {

module.exports = require("@hookform/resolvers/yup");

/***/ }),

/***/ 2376:
/***/ ((module) => {

module.exports = require("axios");

/***/ }),

/***/ 8023:
/***/ ((module) => {

module.exports = require("body-scroll-lock");

/***/ }),

/***/ 3687:
/***/ ((module) => {

module.exports = require("camelcase-keys");

/***/ }),

/***/ 4058:
/***/ ((module) => {

module.exports = require("classnames");

/***/ }),

/***/ 8250:
/***/ ((module) => {

module.exports = require("jotai");

/***/ }),

/***/ 3837:
/***/ ((module) => {

module.exports = require("jotai/utils");

/***/ }),

/***/ 6155:
/***/ ((module) => {

module.exports = require("js-cookie");

/***/ }),

/***/ 3089:
/***/ ((module) => {

module.exports = require("lodash/groupBy");

/***/ }),

/***/ 8718:
/***/ ((module) => {

module.exports = require("lodash/isEmpty");

/***/ }),

/***/ 4661:
/***/ ((module) => {

module.exports = require("lodash/pickBy");

/***/ }),

/***/ 8475:
/***/ ((module) => {

module.exports = require("next-i18next");

/***/ }),

/***/ 3295:
/***/ ((module) => {

module.exports = require("next-i18next/serverSideTranslations");

/***/ }),

/***/ 9325:
/***/ ((module) => {

module.exports = require("next/dist/server/denormalize-page-path.js");

/***/ }),

/***/ 822:
/***/ ((module) => {

module.exports = require("next/dist/server/image-config.js");

/***/ }),

/***/ 6695:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 8300:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/detect-domain-locale.js");

/***/ }),

/***/ 5378:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 2307:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/loadable.js");

/***/ }),

/***/ 7162:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 8773:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 2248:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 9372:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 665:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 2747:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 333:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 3456:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 556:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/to-base-64.js");

/***/ }),

/***/ 7620:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 6731:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 1958:
/***/ ((module) => {

module.exports = require("overlayscrollbars-react");

/***/ }),

/***/ 1346:
/***/ ((module) => {

module.exports = require("rc-drawer");

/***/ }),

/***/ 9297:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 9081:
/***/ ((module) => {

module.exports = require("react-content-loader");

/***/ }),

/***/ 2662:
/***/ ((module) => {

module.exports = require("react-hook-form");

/***/ }),

/***/ 182:
/***/ ((module) => {

module.exports = require("react-mailchimp-subscribe");

/***/ }),

/***/ 2585:
/***/ ((module) => {

module.exports = require("react-query");

/***/ }),

/***/ 9475:
/***/ ((module) => {

module.exports = require("react-query/hydration");

/***/ }),

/***/ 173:
/***/ ((module) => {

module.exports = require("react-use/lib/useLocalStorage");

/***/ }),

/***/ 5319:
/***/ ((module) => {

module.exports = require("react-use/lib/useWindowSize");

/***/ }),

/***/ 5282:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 4074:
/***/ ((module) => {

module.exports = require("swiper");

/***/ }),

/***/ 2156:
/***/ ((module) => {

module.exports = require("swiper/react");

/***/ }),

/***/ 9440:
/***/ ((module) => {

module.exports = require("yup");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [8688,7228,5396,8147,4596,7993,2338,4068,3923,2405,7831,135,5013,4636,3475,8510,7114,5767,1349,5612], () => (__webpack_exec__(3015)));
module.exports = __webpack_exports__;

})();