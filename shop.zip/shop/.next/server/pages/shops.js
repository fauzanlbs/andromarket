"use strict";
(() => {
var exports = {};
exports.id = 4646;
exports.ids = [4646];
exports.modules = {

/***/ 1185:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ ShopsPage),
  "getStaticProps": () => (/* reexport */ getStaticProps)
});

// EXTERNAL MODULE: ./src/components/layout/layout.tsx + 21 modules
var layout = __webpack_require__(4596);
// EXTERNAL MODULE: ./src/components/ui/container.tsx
var container = __webpack_require__(8835);
// EXTERNAL MODULE: ./src/components/common/subscription.tsx
var subscription = __webpack_require__(3923);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(9297);
// EXTERNAL MODULE: ../node_modules/react-icons/fa/index.esm.js
var index_esm = __webpack_require__(7228);
// EXTERNAL MODULE: external "next-i18next"
var external_next_i18next_ = __webpack_require__(8475);
// EXTERNAL MODULE: ./src/components/ui/link.tsx
var ui_link = __webpack_require__(1420);
// EXTERNAL MODULE: ../node_modules/next/image.js
var next_image = __webpack_require__(8579);
// EXTERNAL MODULE: external "classnames"
var external_classnames_ = __webpack_require__(4058);
var external_classnames_default = /*#__PURE__*/__webpack_require__.n(external_classnames_);
// EXTERNAL MODULE: ./src/lib/format-address.ts
var format_address = __webpack_require__(2528);
// EXTERNAL MODULE: external "lodash/isEmpty"
var isEmpty_ = __webpack_require__(8718);
var isEmpty_default = /*#__PURE__*/__webpack_require__.n(isEmpty_);
// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(5282);
;// CONCATENATED MODULE: ./src/components/common/vendor-card.tsx










const VendorCard = ({
  shop,
  variant = "list"
}) => {
  var _logo$thumbnail;

  const {
    t
  } = (0,external_next_i18next_.useTranslation)();
  const placeholderImage = `/assets/placeholder/products/product-grid.svg`;
  const {
    name,
    slug,
    address,
    logo,
    is_active
  } = shop;
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)(ui_link/* default */.Z, {
    href: `shops/${slug}`,
    className: external_classnames_default()("flex items-center px-5 lg:px-6 rounded-md shadow-vendorCard cursor-pointer relative bg-white transition-all hover:shadow-vendorCardHover", {
      "pt-10 lg:pt-12 pb-9 lg:pb-11 flex-col text-center": variant === "grid",
      "py-7 lg:py-8": variant === "list"
    }),
    children: [is_active && /*#__PURE__*/jsx_runtime_.jsx("span", {
      className: "text-[10px] xl:text-xs font-semibold text-white uppercase px-2 py-1 xl:py-[5px] rounded bg-[#2B78C6] absolute top-2 end-2",
      children: "New"
    }), /*#__PURE__*/jsx_runtime_.jsx("div", {
      className: external_classnames_default()("border border-gray-100 relative flex flex-shrink-0 items-center justify-center bg-gray-300 rounded-full overflow-hidden", {
        "w-24 h-24 lg:w-28 lg:h-28": variant === "grid",
        "w-16 h-16": variant === "list"
      }),
      children: /*#__PURE__*/jsx_runtime_.jsx(next_image.default, {
        alt: t("common:text-logo"),
        src: (_logo$thumbnail = logo === null || logo === void 0 ? void 0 : logo.thumbnail) !== null && _logo$thumbnail !== void 0 ? _logo$thumbnail : placeholderImage,
        layout: "fill",
        objectFit: "cover"
      })
    }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      className: external_classnames_default()("flex flex-col", {
        "mb-1 pt-4 md:pt-5 lg:pt-6": variant === "grid",
        "ms-4": variant === "list"
      }),
      children: [/*#__PURE__*/jsx_runtime_.jsx("h4", {
        className: external_classnames_default()("text-heading font-semibold text-sm leading-5 sm:leading-6 lg:leading-7 md:text-base xl:text-lg", {
          "2xl:text-xl mb-1.5": variant === "grid",
          "mb-1 md:mb-0.5": variant === "list"
        }),
        children: name
      }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("p", {
        className: external_classnames_default()("text-[13px] leading-5 flex items-start", {
          "text-sm": variant === "grid"
        }),
        children: [/*#__PURE__*/jsx_runtime_.jsx("span", {
          className: "inline-block me-1 text-[#6B7280] relative top-1",
          children: /*#__PURE__*/jsx_runtime_.jsx(index_esm/* FaMapMarkerAlt */.Nh4, {})
        }), !isEmpty_default()((0,format_address/* formatAddress */.T)(address)) ? (0,format_address/* formatAddress */.T)(address) : t("text-no-address")]
      })]
    })]
  });
};

/* harmony default export */ const vendor_card = (VendorCard);
// EXTERNAL MODULE: ./src/components/ui/alert.tsx
var ui_alert = __webpack_require__(5013);
// EXTERNAL MODULE: ../node_modules/react-icons/bs/index.esm.js
var bs_index_esm = __webpack_require__(3218);
// EXTERNAL MODULE: ./src/framework/rest/shops/shops.query.ts
var shops_query = __webpack_require__(3788);
// EXTERNAL MODULE: ./src/components/ui/button.tsx
var ui_button = __webpack_require__(7993);
;// CONCATENATED MODULE: ./src/components/shops/shops-page-content.tsx










const ShopsPageContent = () => {
  var _data$pages;

  const {
    0: gridView,
    1: setGridView
  } = (0,external_react_.useState)(Boolean(false));
  const {
    t
  } = (0,external_next_i18next_.useTranslation)();
  const {
    data,
    isFetching: loading,
    isFetchingNextPage: loadingMore,
    fetchNextPage,
    hasNextPage,
    error
  } = (0,shops_query/* useShopsQuery */.uL)({
    is_active: 1
  });

  const listViewHandel = () => {
    setTimeout(() => {
      setGridView(false);
    }, 300);
  };

  const gridViewHandel = () => {
    setTimeout(() => {
      setGridView(true);
    }, 300);
  };

  if (error) return /*#__PURE__*/jsx_runtime_.jsx(ui_alert/* default */.Z, {
    message: error === null || error === void 0 ? void 0 : error.message
  });
  return /*#__PURE__*/jsx_runtime_.jsx("div", {
    className: "border-t border-gray-300 pt-10 lg:pt-12 xl:pt-14 pb-14 lg:pb-16 xl:pb-20 px-4 md:px-8",
    children: /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
      className: "w-full xl:max-w-[1170px] mx-auto",
      children: [/*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
        className: "flex items-center justify-between mb-6 xl:mb-8",
        children: [/*#__PURE__*/jsx_runtime_.jsx("h2", {
          className: "font-bold text-heading text-lg md:text-xl lg:text-2xl xl:text-3xl",
          children: t('text-shops-title')
        }), /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
          className: "flex-shrink-0 flex items-center space-x-1.5 ms-2",
          children: [/*#__PURE__*/jsx_runtime_.jsx("button", {
            "aria-label": "list",
            className: `text-2xl relative top-[1px] transition-all ${gridView === false ? "text-heading" : "text-body"}`,
            onClick: listViewHandel,
            children: /*#__PURE__*/jsx_runtime_.jsx(bs_index_esm/* BsList */.Ps6, {
              className: ""
            })
          }), /*#__PURE__*/jsx_runtime_.jsx("button", {
            "aria-label": "grid",
            className: `text-lg transition-all ${gridView === true ? "text-heading" : "text-body"}`,
            onClick: gridViewHandel,
            children: /*#__PURE__*/jsx_runtime_.jsx(bs_index_esm/* BsGridFill */.H9n, {})
          })]
        })]
      }), /*#__PURE__*/jsx_runtime_.jsx("div", {
        className: "grid md:grid-cols-2 lg:grid-cols-3 gap-3 md:gap-4 lg:gap-5 xl:gap-6",
        children: !loading && (data === null || data === void 0 ? void 0 : (_data$pages = data.pages) === null || _data$pages === void 0 ? void 0 : _data$pages.map((page, idx) => {
          return /*#__PURE__*/jsx_runtime_.jsx(external_react_.Fragment, {
            children: page.data.map(shop => /*#__PURE__*/jsx_runtime_.jsx(vendor_card, {
              shop: shop,
              variant: gridView === true ? "grid" : "list"
            }, shop.id))
          }, idx);
        }))
      }), hasNextPage && /*#__PURE__*/jsx_runtime_.jsx("div", {
        className: "text-center pt-8 xl:pt-14",
        children: /*#__PURE__*/jsx_runtime_.jsx(ui_button/* default */.Z, {
          loading: loadingMore,
          disabled: loadingMore,
          onClick: () => fetchNextPage(),
          variant: "slim",
          children: t("button-load-more")
        })
      })]
    })
  });
};

/* harmony default export */ const shops_page_content = (ShopsPageContent);
// EXTERNAL MODULE: ./src/framework/rest/settings/settings.query.ts
var settings_query = __webpack_require__(659);
// EXTERNAL MODULE: ./src/framework/rest/brand/brands.query.tsx
var brands_query = __webpack_require__(4412);
// EXTERNAL MODULE: ./src/framework/rest/utils/endpoints.ts
var endpoints = __webpack_require__(874);
// EXTERNAL MODULE: external "next-i18next/serverSideTranslations"
var serverSideTranslations_ = __webpack_require__(3295);
// EXTERNAL MODULE: external "react-query"
var external_react_query_ = __webpack_require__(2585);
// EXTERNAL MODULE: external "react-query/hydration"
var hydration_ = __webpack_require__(9475);
;// CONCATENATED MODULE: ./src/framework/rest/ssr/shops.ts
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) { symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); } keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }








const getStaticProps = async ({
  locale
}) => {
  const queryClient = new external_react_query_.QueryClient();
  await queryClient.prefetchQuery(endpoints/* API_ENDPOINTS.SETTINGS */.P.SETTINGS, settings_query/* fetchSettings */.w);
  await queryClient.prefetchQuery(endpoints/* API_ENDPOINTS.TYPE */.P.TYPE, brands_query/* fetchBrands */.S0, {
    staleTime: 60 * 1000
  });
  await queryClient.prefetchInfiniteQuery([endpoints/* API_ENDPOINTS.SHOPS */.P.SHOPS, {
    is_active: 1
  }], shops_query/* fetchShops */.NB);
  return {
    props: _objectSpread(_objectSpread({}, await (0,serverSideTranslations_.serverSideTranslations)(locale, ["common", "menu", "forms", "footer"])), {}, {
      dehydratedState: JSON.parse(JSON.stringify((0,hydration_.dehydrate)(queryClient)))
    })
  };
};
;// CONCATENATED MODULE: ./src/pages/shops/index.tsx








function ShopsPage() {
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
    children: [/*#__PURE__*/jsx_runtime_.jsx(shops_page_content, {}), /*#__PURE__*/jsx_runtime_.jsx(container/* default */.Z, {
      children: /*#__PURE__*/jsx_runtime_.jsx(subscription/* default */.Z, {})
    })]
  });
}
ShopsPage.getLayout = layout/* getLayout */.G;

/***/ }),

/***/ 2166:
/***/ ((module) => {

module.exports = require("@hookform/resolvers/yup");

/***/ }),

/***/ 2376:
/***/ ((module) => {

module.exports = require("axios");

/***/ }),

/***/ 8023:
/***/ ((module) => {

module.exports = require("body-scroll-lock");

/***/ }),

/***/ 3687:
/***/ ((module) => {

module.exports = require("camelcase-keys");

/***/ }),

/***/ 4058:
/***/ ((module) => {

module.exports = require("classnames");

/***/ }),

/***/ 8250:
/***/ ((module) => {

module.exports = require("jotai");

/***/ }),

/***/ 3837:
/***/ ((module) => {

module.exports = require("jotai/utils");

/***/ }),

/***/ 6155:
/***/ ((module) => {

module.exports = require("js-cookie");

/***/ }),

/***/ 3089:
/***/ ((module) => {

module.exports = require("lodash/groupBy");

/***/ }),

/***/ 8718:
/***/ ((module) => {

module.exports = require("lodash/isEmpty");

/***/ }),

/***/ 4661:
/***/ ((module) => {

module.exports = require("lodash/pickBy");

/***/ }),

/***/ 8475:
/***/ ((module) => {

module.exports = require("next-i18next");

/***/ }),

/***/ 3295:
/***/ ((module) => {

module.exports = require("next-i18next/serverSideTranslations");

/***/ }),

/***/ 9325:
/***/ ((module) => {

module.exports = require("next/dist/server/denormalize-page-path.js");

/***/ }),

/***/ 822:
/***/ ((module) => {

module.exports = require("next/dist/server/image-config.js");

/***/ }),

/***/ 6695:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 8300:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/detect-domain-locale.js");

/***/ }),

/***/ 5378:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 2307:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/loadable.js");

/***/ }),

/***/ 7162:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 8773:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 2248:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 9372:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 665:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 2747:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 333:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 3456:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 556:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/to-base-64.js");

/***/ }),

/***/ 7620:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 6731:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 1958:
/***/ ((module) => {

module.exports = require("overlayscrollbars-react");

/***/ }),

/***/ 1346:
/***/ ((module) => {

module.exports = require("rc-drawer");

/***/ }),

/***/ 9297:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 9081:
/***/ ((module) => {

module.exports = require("react-content-loader");

/***/ }),

/***/ 2662:
/***/ ((module) => {

module.exports = require("react-hook-form");

/***/ }),

/***/ 182:
/***/ ((module) => {

module.exports = require("react-mailchimp-subscribe");

/***/ }),

/***/ 2585:
/***/ ((module) => {

module.exports = require("react-query");

/***/ }),

/***/ 9475:
/***/ ((module) => {

module.exports = require("react-query/hydration");

/***/ }),

/***/ 173:
/***/ ((module) => {

module.exports = require("react-use/lib/useLocalStorage");

/***/ }),

/***/ 5282:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 9440:
/***/ ((module) => {

module.exports = require("yup");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [8688,7228,3218,5396,8147,4596,7993,2338,4068,3923,2405,7831,5013,6098,3788], () => (__webpack_exec__(1185)));
module.exports = __webpack_exports__;

})();