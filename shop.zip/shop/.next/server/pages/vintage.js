"use strict";
(() => {
var exports = {};
exports.id = 4052;
exports.ids = [4052];
exports.modules = {

/***/ 9223:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ Home),
  "getStaticProps": () => (/* reexport */ pages/* getStaticProps */.b)
});

// EXTERNAL MODULE: ./src/components/common/banner-card.tsx
var banner_card = __webpack_require__(5038);
// EXTERNAL MODULE: ./src/components/ui/container.tsx
var container = __webpack_require__(8835);
// EXTERNAL MODULE: ./src/containers/brand-block.tsx
var brand_block = __webpack_require__(5748);
// EXTERNAL MODULE: ./src/containers/category-block.tsx + 1 modules
var category_block = __webpack_require__(5767);
// EXTERNAL MODULE: ./src/containers/category-grid-block.tsx + 3 modules
var category_grid_block = __webpack_require__(5467);
// EXTERNAL MODULE: ./src/components/layout/layout.tsx + 21 modules
var layout = __webpack_require__(4596);
// EXTERNAL MODULE: ./src/containers/banner-with-products.tsx + 1 modules
var banner_with_products = __webpack_require__(1040);
// EXTERNAL MODULE: ./src/components/product/feeds/new-arrivals-product-feed.tsx
var new_arrivals_product_feed = __webpack_require__(4584);
// EXTERNAL MODULE: ./src/components/ui/divider.tsx
var divider = __webpack_require__(5313);
// EXTERNAL MODULE: ./src/components/common/download-apps.tsx
var download_apps = __webpack_require__(7195);
// EXTERNAL MODULE: ./src/components/common/support.tsx
var support = __webpack_require__(7063);
// EXTERNAL MODULE: ./src/components/common/instagram.tsx + 1 modules
var instagram = __webpack_require__(7141);
// EXTERNAL MODULE: ./src/containers/product-flash-sale-block.tsx + 1 modules
var product_flash_sale_block = __webpack_require__(9637);
// EXTERNAL MODULE: ./src/containers/products-featured.tsx + 1 modules
var products_featured = __webpack_require__(1403);
// EXTERNAL MODULE: ./src/containers/banner-slider-block.tsx
var banner_slider_block = __webpack_require__(1123);
// EXTERNAL MODULE: ./src/containers/exclusive-block.tsx
var exclusive_block = __webpack_require__(5810);
// EXTERNAL MODULE: ./src/components/common/category-list-card.tsx
var category_list_card = __webpack_require__(1648);
// EXTERNAL MODULE: ./src/components/common/sale-with-progress.tsx + 3 modules
var sale_with_progress = __webpack_require__(2577);
// EXTERNAL MODULE: ./src/components/ui/carousel/carousel.tsx
var carousel = __webpack_require__(4365);
// EXTERNAL MODULE: external "swiper/react"
var react_ = __webpack_require__(2156);
// EXTERNAL MODULE: ./src/framework/rest/category/categories.query.ts
var categories_query = __webpack_require__(4362);
// EXTERNAL MODULE: ./src/framework/rest/products/products.query.ts
var products_query = __webpack_require__(2317);
// EXTERNAL MODULE: ./src/utils/use-window-size.ts
var use_window_size = __webpack_require__(3396);
// EXTERNAL MODULE: ./src/components/ui/loaders/category-list-card-loader.tsx
var category_list_card_loader = __webpack_require__(256);
// EXTERNAL MODULE: ./src/lib/routes.ts
var routes = __webpack_require__(1103);
// EXTERNAL MODULE: ./src/components/ui/alert.tsx
var ui_alert = __webpack_require__(5013);
// EXTERNAL MODULE: external "next-i18next"
var external_next_i18next_ = __webpack_require__(8475);
// EXTERNAL MODULE: external "lodash/isEmpty"
var isEmpty_ = __webpack_require__(8718);
var isEmpty_default = /*#__PURE__*/__webpack_require__.n(isEmpty_);
// EXTERNAL MODULE: ./src/components/404/not-found-item.tsx
var not_found_item = __webpack_require__(6857);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(9297);
// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(5282);
;// CONCATENATED MODULE: ./src/containers/hero-with-category-flash.tsx


















const categoryResponsive = {
  "768": {
    slidesPerView: 3,
    spaceBetween: 14
  },
  "480": {
    slidesPerView: 2,
    spaceBetween: 12
  },
  "0": {
    slidesPerView: 1,
    spaceBetween: 12
  }
};

const HeroWithCategoryFlash = ({
  className = "mb-12 md:mb-14 xl:mb-16",
  banners
}) => {
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)("div", {
    className: `grid grid-cols-1 lg:grid-cols-7 2xl:grid-cols-9 gap-5 xl:gap-7 lg:gap-y-14 ${className}`,
    children: [/*#__PURE__*/jsx_runtime_.jsx(CategoryListCardSection, {}), /*#__PURE__*/jsx_runtime_.jsx("div", {
      className: "col-span-full lg:col-span-5 xl:col-span-5 row-span-full lg:row-auto grid grid-cols-2 gap-2 md:gap-3.5 lg:gap-5 xl:gap-7",
      children: banners.map(banner => /*#__PURE__*/jsx_runtime_.jsx(banner_card/* default */.Z, {
        banner: banner,
        href: `${routes/* ROUTES.COLLECTIONS */.Z.COLLECTIONS}/${banner.slug}`,
        className: banner.type === "large" ? "col-span-2" : "col-span-1"
      }, `banner--key${banner.id}`))
    }), /*#__PURE__*/jsx_runtime_.jsx(SellWithProgressCardSection, {})]
  });
}; // CategoryList section


function CategoryListCardSection() {
  var _categories$pages, _categories$pages$, _categories$pages$2;

  const {
    t
  } = (0,external_next_i18next_.useTranslation)();
  const {
    width
  } = (0,use_window_size/* useWindowSize */.i)();
  const {
    data: categories,
    isLoading: loading,
    error
  } = (0,categories_query/* useCategoriesQuery */.E)({
    limit: 10,
    parent: null
  });

  if (!loading && isEmpty_default()(categories === null || categories === void 0 ? void 0 : (_categories$pages = categories.pages) === null || _categories$pages === void 0 ? void 0 : _categories$pages[0].data)) {
    return /*#__PURE__*/jsx_runtime_.jsx(not_found_item/* default */.Z, {
      text: t("text-no-categories-found")
    });
  }

  return /*#__PURE__*/jsx_runtime_.jsx(jsx_runtime_.Fragment, {
    children: error ? /*#__PURE__*/jsx_runtime_.jsx("div", {
      className: "col-span-full lg:col-span-2",
      children: /*#__PURE__*/jsx_runtime_.jsx(ui_alert/* default */.Z, {
        message: error === null || error === void 0 ? void 0 : error.message
      })
    }) : width < 1025 ? /*#__PURE__*/jsx_runtime_.jsx("div", {
      className: "col-span-full",
      children: /*#__PURE__*/jsx_runtime_.jsx(carousel/* default */.Z, {
        breakpoints: categoryResponsive,
        buttonSize: "small",
        children: loading ? Array.from({
          length: 7
        }).map((_, idx) => /*#__PURE__*/jsx_runtime_.jsx(react_.SwiperSlide, {
          children: /*#__PURE__*/jsx_runtime_.jsx(category_list_card_loader/* default */.Z, {
            uniqueKey: `category-list-${idx}`
          })
        }, idx)) : categories === null || categories === void 0 ? void 0 : (_categories$pages$ = categories.pages[0]) === null || _categories$pages$ === void 0 ? void 0 : _categories$pages$.data.map(category => /*#__PURE__*/jsx_runtime_.jsx(react_.SwiperSlide, {
          children: /*#__PURE__*/jsx_runtime_.jsx(category_list_card/* default */.Z, {
            category: category
          })
        }, `sm-category--key${category.id}`))
      })
    }) : /*#__PURE__*/jsx_runtime_.jsx("div", {
      className: "col-span-full lg:col-span-2 grid grid-cols-1 gap-3 justify-between",
      children: loading ? Array.from({
        length: 7
      }).map((_, idx) => /*#__PURE__*/jsx_runtime_.jsx(category_list_card_loader/* default */.Z, {
        uniqueKey: `category-list-${idx}`
      }, idx)) : categories === null || categories === void 0 ? void 0 : (_categories$pages$2 = categories.pages[0]) === null || _categories$pages$2 === void 0 ? void 0 : _categories$pages$2.data.slice(0, 7).map(category => /*#__PURE__*/jsx_runtime_.jsx(category_list_card/* default */.Z, {
        category: category
      }, `lg-category--key${category.id}`))
    })
  });
} // ProgressCard section

function SellWithProgressCardSection() {
  var _products$pages;

  const {
    width
  } = (0,use_window_size/* useWindowSize */.i)();
  const {
    t
  } = (0,external_next_i18next_.useTranslation)();
  const {
    data: products,
    isLoading: loading,
    error
  } = (0,products_query/* useProductsQuery */.kN)({
    limit: 10
  });

  if (!loading && isEmpty_default()(products === null || products === void 0 ? void 0 : (_products$pages = products.pages) === null || _products$pages === void 0 ? void 0 : _products$pages[0].data)) {
    return /*#__PURE__*/jsx_runtime_.jsx(not_found_item/* default */.Z, {
      text: t("text-no-products-found")
    });
  }

  return /*#__PURE__*/jsx_runtime_.jsx(jsx_runtime_.Fragment, {
    children: width < 1441 ? /*#__PURE__*/jsx_runtime_.jsx(sale_with_progress/* default */.Z // TODO: Fix the types
    // @ts-ignore
    , {
      products: products === null || products === void 0 ? void 0 : products.pages[0].data,
      className: "col-span-full",
      loading: loading,
      error: error === null || error === void 0 ? void 0 : error.message
    }) : /*#__PURE__*/jsx_runtime_.jsx(sale_with_progress/* default */.Z // TODO: Fix the types
    // @ts-ignore
    , {
      products: products === null || products === void 0 ? void 0 : products.pages[0].data,
      productVariant: "gridSlim",
      loading: loading,
      imgWidth: 330,
      imgHeight: 425,
      error: error === null || error === void 0 ? void 0 : error.message,
      className: "col-span-full 2xl:col-span-2 2xl:row-auto xl:hidden 2xl:flex"
    })
  });
}
/* harmony default export */ const hero_with_category_flash = (HeroWithCategoryFlash);
// EXTERNAL MODULE: ./src/components/common/subscription.tsx
var subscription = __webpack_require__(3923);
// EXTERNAL MODULE: ./src/framework/rest/banner/banner.query.ts
var banner_query = __webpack_require__(9658);
// EXTERNAL MODULE: ./src/framework/rest/ssr/pages.ts
var pages = __webpack_require__(9218);
;// CONCATENATED MODULE: ./src/pages/vintage.tsx
























function Home() {
  var _banners$homeFourBann, _banners$homeFourBann2, _banners$homeFourBann3, _banners$homeFourBann4, _banners$homeFourBann5, _banners$homeFourBann6;

  const {
    data: banners
  } = (0,banner_query/* useBannerQuery */.E)();
  return /*#__PURE__*/(0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
    children: [/*#__PURE__*/jsx_runtime_.jsx(container/* default */.Z, {
      children: /*#__PURE__*/jsx_runtime_.jsx(hero_with_category_flash, {
        banners: banners === null || banners === void 0 ? void 0 : banners.homeFourGridBanners
      })
    }), /*#__PURE__*/jsx_runtime_.jsx(banner_slider_block/* default */.Z, {
      banners: banners === null || banners === void 0 ? void 0 : banners.promotionBanner
    }), /*#__PURE__*/(0,jsx_runtime_.jsxs)(container/* default */.Z, {
      children: [/*#__PURE__*/jsx_runtime_.jsx(category_block/* default */.Z, {
        sectionHeading: "text-shop-by-category"
      }), /*#__PURE__*/jsx_runtime_.jsx(banner_with_products/* default */.Z, {
        sectionHeading: "text-on-selling-products",
        categorySlug: "/search",
        variant: "reverse",
        banner: banners === null || banners === void 0 ? void 0 : banners.homeThreeProductsBanner
      }), /*#__PURE__*/jsx_runtime_.jsx(banner_card/* default */.Z, {
        banner: banners === null || banners === void 0 ? void 0 : (_banners$homeFourBann = banners.homeFourBanner) === null || _banners$homeFourBann === void 0 ? void 0 : _banners$homeFourBann[0],
        href: `${routes/* ROUTES.COLLECTIONS */.Z.COLLECTIONS}/${banners === null || banners === void 0 ? void 0 : (_banners$homeFourBann2 = banners.homeFourBanner) === null || _banners$homeFourBann2 === void 0 ? void 0 : _banners$homeFourBann2[0].slug}`,
        className: "mb-11 md:mb-12 lg:mb-14 2xl:mb-16"
      }), /*#__PURE__*/jsx_runtime_.jsx(products_featured/* default */.Z, {
        sectionHeading: "text-featured-products",
        variant: "center"
      }), /*#__PURE__*/jsx_runtime_.jsx(banner_card/* default */.Z, {
        banner: banners === null || banners === void 0 ? void 0 : (_banners$homeFourBann3 = banners.homeFourBanner) === null || _banners$homeFourBann3 === void 0 ? void 0 : _banners$homeFourBann3[1],
        href: `${routes/* ROUTES.COLLECTIONS */.Z.COLLECTIONS}/${banners === null || banners === void 0 ? void 0 : (_banners$homeFourBann4 = banners.homeFourBanner) === null || _banners$homeFourBann4 === void 0 ? void 0 : _banners$homeFourBann4[1].slug}`,
        className: "mb-11 md:mb-12 lg:mb-14 2xl:mb-16"
      }), /*#__PURE__*/jsx_runtime_.jsx(product_flash_sale_block/* default */.Z, {
        date: "2023-03-01T01:02:03"
      }), /*#__PURE__*/jsx_runtime_.jsx(brand_block/* default */.Z, {
        sectionHeading: "text-top-brands"
      }), /*#__PURE__*/jsx_runtime_.jsx(exclusive_block/* default */.Z, {}), /*#__PURE__*/jsx_runtime_.jsx(new_arrivals_product_feed/* default */.Z, {}), /*#__PURE__*/jsx_runtime_.jsx(banner_card/* default */.Z, {
        banner: banners === null || banners === void 0 ? void 0 : (_banners$homeFourBann5 = banners.homeFourBanner) === null || _banners$homeFourBann5 === void 0 ? void 0 : _banners$homeFourBann5[2],
        href: `${routes/* ROUTES.COLLECTIONS */.Z.COLLECTIONS}/${banners === null || banners === void 0 ? void 0 : (_banners$homeFourBann6 = banners.homeFourBanner) === null || _banners$homeFourBann6 === void 0 ? void 0 : _banners$homeFourBann6[2].slug}`,
        className: "mb-12 lg:mb-14 xl:mb-16 pb-0.5 lg:pb-1 xl:pb-0"
      }), /*#__PURE__*/jsx_runtime_.jsx(category_grid_block/* default */.Z, {
        sectionHeading: "text-featured-categories"
      }), /*#__PURE__*/jsx_runtime_.jsx(download_apps/* default */.Z, {}), /*#__PURE__*/jsx_runtime_.jsx(support/* default */.Z, {}), /*#__PURE__*/jsx_runtime_.jsx(instagram/* default */.Z, {}), /*#__PURE__*/jsx_runtime_.jsx(subscription/* default */.Z, {
        className: "bg-opacity-0 px-5 sm:px-16 xl:px-0 py-12 md:py-14 xl:py-16"
      })]
    }), /*#__PURE__*/jsx_runtime_.jsx(divider/* default */.Z, {
      className: "mb-0"
    })]
  });
}
Home.getLayout = layout/* getLayout */.G;

/***/ }),

/***/ 2166:
/***/ ((module) => {

module.exports = require("@hookform/resolvers/yup");

/***/ }),

/***/ 2376:
/***/ ((module) => {

module.exports = require("axios");

/***/ }),

/***/ 8023:
/***/ ((module) => {

module.exports = require("body-scroll-lock");

/***/ }),

/***/ 3687:
/***/ ((module) => {

module.exports = require("camelcase-keys");

/***/ }),

/***/ 4058:
/***/ ((module) => {

module.exports = require("classnames");

/***/ }),

/***/ 8250:
/***/ ((module) => {

module.exports = require("jotai");

/***/ }),

/***/ 3837:
/***/ ((module) => {

module.exports = require("jotai/utils");

/***/ }),

/***/ 6155:
/***/ ((module) => {

module.exports = require("js-cookie");

/***/ }),

/***/ 3089:
/***/ ((module) => {

module.exports = require("lodash/groupBy");

/***/ }),

/***/ 8718:
/***/ ((module) => {

module.exports = require("lodash/isEmpty");

/***/ }),

/***/ 4661:
/***/ ((module) => {

module.exports = require("lodash/pickBy");

/***/ }),

/***/ 8475:
/***/ ((module) => {

module.exports = require("next-i18next");

/***/ }),

/***/ 3295:
/***/ ((module) => {

module.exports = require("next-i18next/serverSideTranslations");

/***/ }),

/***/ 9325:
/***/ ((module) => {

module.exports = require("next/dist/server/denormalize-page-path.js");

/***/ }),

/***/ 822:
/***/ ((module) => {

module.exports = require("next/dist/server/image-config.js");

/***/ }),

/***/ 6695:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 8300:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/detect-domain-locale.js");

/***/ }),

/***/ 5378:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 2307:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/loadable.js");

/***/ }),

/***/ 7162:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 8773:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 2248:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 9372:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 665:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 2747:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 333:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 3456:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 556:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/to-base-64.js");

/***/ }),

/***/ 7620:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 6731:
/***/ ((module) => {

module.exports = require("next/router");

/***/ }),

/***/ 1958:
/***/ ((module) => {

module.exports = require("overlayscrollbars-react");

/***/ }),

/***/ 1346:
/***/ ((module) => {

module.exports = require("rc-drawer");

/***/ }),

/***/ 9297:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 9081:
/***/ ((module) => {

module.exports = require("react-content-loader");

/***/ }),

/***/ 2662:
/***/ ((module) => {

module.exports = require("react-hook-form");

/***/ }),

/***/ 182:
/***/ ((module) => {

module.exports = require("react-mailchimp-subscribe");

/***/ }),

/***/ 2585:
/***/ ((module) => {

module.exports = require("react-query");

/***/ }),

/***/ 9475:
/***/ ((module) => {

module.exports = require("react-query/hydration");

/***/ }),

/***/ 173:
/***/ ((module) => {

module.exports = require("react-use/lib/useLocalStorage");

/***/ }),

/***/ 5319:
/***/ ((module) => {

module.exports = require("react-use/lib/useWindowSize");

/***/ }),

/***/ 5282:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ }),

/***/ 4074:
/***/ ((module) => {

module.exports = require("swiper");

/***/ }),

/***/ 2156:
/***/ ((module) => {

module.exports = require("swiper/react");

/***/ }),

/***/ 9440:
/***/ ((module) => {

module.exports = require("yup");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [8688,7228,5396,8147,4596,7993,2338,4068,3923,2405,7831,135,5013,4636,9204,3475,8510,7114,5767,8530,1349,3247], () => (__webpack_exec__(9223)));
module.exports = __webpack_exports__;

})();