import "react-tabs/style/react-tabs.css";
export { Tab, Tabs, TabList, TabPanel } from "react-tabs";
